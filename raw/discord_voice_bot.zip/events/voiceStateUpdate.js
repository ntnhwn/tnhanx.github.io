import fs from 'fs';
const voiceTimes = {};

export default {
  name: 'voiceStateUpdate',
  async execute(oldState, newState, client) {
    const user = newState.member || oldState.member;
    if (!user || user.user.bot) return;

    const dataPath = './data/voiceData.json';
    const logPath = './data/logChannel.json';
    const now = Date.now();

    if (newState.channelId && !oldState.channelId) {
      voiceTimes[user.id] = now;

      const me = newState.guild.members.me;
      if (!newState.channel.members.has(me.id)) {
        try {
          await newState.channel.joinable && await newState.channel.join();
        } catch {}
      }
    }

    if (oldState.channelId && !newState.channelId) {
      if (voiceTimes[user.id]) {
        const duration = Math.floor((now - voiceTimes[user.id]) / 1000);
        delete voiceTimes[user.id];

        const data = fs.existsSync(dataPath) ? JSON.parse(fs.readFileSync(dataPath)) : {};
        data[user.id] = (data[user.id] || 0) + duration;
        fs.writeFileSync(dataPath, JSON.stringify(data));

        if (fs.existsSync(logPath)) {
          const { channelId } = JSON.parse(fs.readFileSync(logPath));
          const logChannel = oldState.guild.channels.cache.get(channelId);
          if (logChannel) {
            logChannel.send(`👤 **${user.user.username}** rời voice sau ${Math.floor(duration / 60)} phút.`);
          }
        }
      }

      const channel = oldState.channel;
      if (channel && channel.members.filter(m => !m.user.bot).size === 0) {
        try {
          await channel.leave && await channel.leave();
        } catch {}
      }
    }
  }
};