// Deploy lệnh slash
