// Lệnh /ping
