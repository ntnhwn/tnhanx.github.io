import { SlashCommandBuilder } from 'discord.js';
import fs from 'fs';
export default {
  data: new SlashCommandBuilder()
    .setName('setlogchannel')
    .setDescription('Set channel for voice logs')
    .addChannelOption(opt => opt.setName('channel').setDescription('Log channel').setRequired(true)),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    if (!channel || channel.type !== 0) {
      return interaction.reply('Select a text channel.');
    }
    fs.writeFileSync('./data/logChannel.json', JSON.stringify({ channelId: channel.id }));
    await interaction.reply(`✅ Log channel set to ${channel}`);
  }
};