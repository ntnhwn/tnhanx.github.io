import { SlashCommandBuilder } from 'discord.js';
import fs from 'fs';
export default {
  data: new SlashCommandBuilder().setName('topvoice').setDescription('Show top voice users'),
  async execute(interaction) {
    if (!fs.existsSync('./data/voiceData.json')) {
      return interaction.reply('No voice data yet.');
    }
    const data = JSON.parse(fs.readFileSync('./data/voiceData.json'));
    const arr = Object.entries(data);
    arr.sort((a,b) => b[1] - a[1]);
    const top = arr.slice(0,10).map(([id,sec], i) => {
      const m = interaction.guild.members.cache.get(id);
      const name = m ? m.user.username : id;
      const min = Math.floor(sec / 60);
      return `${i+1}. **${name}** — ${min} phút`;
    });
    await interaction.reply(top.join('\n') || 'No data collected yet.');
  }
};