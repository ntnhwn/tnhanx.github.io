import { SlashCommandBuilder } from 'discord.js';
export default {
  data: new SlashCommandBuilder().setName('help').setDescription('List commands'),
  async execute(interaction) {
    const cmds = [
      '/ping — check latency',
      '/uptime — show uptime',
      '/topvoice — top voice time users',
      '/setlogchannel — set log channel',
      '/help — this list'
    ].join('\n');
    await interaction.reply(`📜 Commands:\n${cmds}`);
  }
};