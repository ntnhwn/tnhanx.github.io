// Lệnh /uptime
