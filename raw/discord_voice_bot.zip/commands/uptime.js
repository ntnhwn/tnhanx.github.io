import { SlashCommandBuilder } from 'discord.js';
const startTime = Date.now();
export default {
  data: new SlashCommandBuilder().setName('uptime').setDescription('Bot uptime'),
  async execute(interaction) {
    const diff = Date.now() - startTime;
    const h = Math.floor(diff / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);
    await interaction.reply(`🕒 Uptime: ${h}h ${m}m ${s}s`);
  }
};