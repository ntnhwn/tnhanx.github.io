const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('uptime').setDescription('Thời gian bot hoạt động'),
  async execute(interaction) {
    const uptime = process.uptime();
    const h = Math.floor(uptime / 3600), m = Math.floor((uptime % 3600) / 60);
    await interaction.reply(`🕒 Bot đã hoạt động: ${h}h ${m}m`);
  },
};