const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('ping').setDescription('Kiểm tra độ trễ'),
  async execute(interaction) {
    const sent = await interaction.reply({ content: '🏓 Pinging...', fetchReply: true });
    interaction.editReply(`📶 Độ trễ: ${sent.createdTimestamp - interaction.createdTimestamp}ms`);
  },
};