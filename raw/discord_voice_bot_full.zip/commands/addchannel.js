const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('addchannel')
    .setDescription('Thêm kênh voice cần theo dõi')
    .addChannelOption(option => option.setName('channel').setDescription('Kênh voice').setRequired(true)),
  async execute(interaction, { trackedChannels }) {
    const channel = interaction.options.getChannel('channel');
    if (!channel.isVoiceBased()) return interaction.reply('❌ Kênh này không phải voice.');
    if (!trackedChannels.includes(channel.id)) trackedChannels.push(channel.id);
    await interaction.reply(`🎧 Đã theo dõi kênh: **${channel.name}**`);
  },
};