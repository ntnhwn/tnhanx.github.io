const { SlashCommandBuilder } = require('discord.js');
module.exports = {
  data: new SlashCommandBuilder().setName('topvoice').setDescription('Top người dùng voice nhiều nhất'),
  async execute(interaction, { voiceStats }) {
    const top = Object.entries(voiceStats)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([id, time], i) => `${i + 1}. <@${id}>: ${(time / 60000).toFixed(1)} phút`).join('\n');
    await interaction.reply(`🎤 **Top voice:**\n${top || 'Chưa có dữ liệu.'}`);
  },
};