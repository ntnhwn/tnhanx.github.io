const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
module.exports = {
  data: new SlashCommandBuilder().setName('setlogchannel').setDescription('Đặt kênh log thông báo'),
  async execute(interaction) {
    const config = require('../config.json');
    config.logChannelId = interaction.channelId;
    fs.writeFileSync('./config.json', JSON.stringify(config, null, 2));
    await interaction.reply('✅ Đã chọn kênh này để gửi thông báo khi voice kết thúc.');
  },
};