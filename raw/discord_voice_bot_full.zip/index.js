require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Collection, Events } = require('discord.js');
const { logChannelId, trackedChannelsFile, dataFile } = require('./config.json');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildVoiceStates,
  ],
});

client.commands = new Collection();
const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  client.commands.set(command.data.name, command);
}

let trackedChannels = [];
let voiceSessions = {};
let voiceStats = {};

// Load tracked channels
if (fs.existsSync(trackedChannelsFile)) {
  trackedChannels = JSON.parse(fs.readFileSync(trackedChannelsFile));
}

// Load voice stats
if (fs.existsSync(dataFile)) {
  voiceStats = JSON.parse(fs.readFileSync(dataFile));
}

client.once(Events.ClientReady, () => {
  console.log(`✅ Logged in as ${client.user.tag}`);
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;
  const command = client.commands.get(interaction.commandName);
  if (!command) return;
  try {
    await command.execute(interaction, { trackedChannels, voiceStats });
    fs.writeFileSync(dataFile, JSON.stringify(voiceStats, null, 2));
    fs.writeFileSync(trackedChannelsFile, JSON.stringify(trackedChannels, null, 2));
  } catch (error) {
    console.error(error);
    await interaction.reply({ content: '❌ Có lỗi xảy ra khi xử lý lệnh.', ephemeral: true });
  }
});

client.on(Events.VoiceStateUpdate, (oldState, newState) => {
  const userId = newState.id;
  const now = Date.now();
  const joinedChannel = newState.channelId;
  const leftChannel = oldState.channelId;

  if (joinedChannel && trackedChannels.includes(joinedChannel)) {
    voiceSessions[userId] = now;
  }

  if (leftChannel && trackedChannels.includes(leftChannel) && voiceSessions[userId]) {
    const duration = now - voiceSessions[userId];
    delete voiceSessions[userId];
    voiceStats[userId] = (voiceStats[userId] || 0) + duration;

    const logChannel = client.channels.cache.get(logChannelId);
    if (logChannel) {
      const member = newState.member;
      logChannel.send(`👤 **${member.user.tag}** vừa rời kênh **${oldState.channel.name}** sau ${(duration / 60000).toFixed(1)} phút.`);
    }
  }
});

client.login(process.env.DISCORD_TOKEN);