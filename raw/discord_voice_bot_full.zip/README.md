# Bot Discord Voice Tracker
Sử dụng slash command và theo dõi thời gian sử dụng voice.