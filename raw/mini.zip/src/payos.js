import crypto from 'crypto';
import axios from 'axios';

const { PAYOS_CLIENT_ID, PAYOS_API_KEY, PAYOS_CHECKSUM_KEY, PAYOS_BASE_URL='https://api-merchant.payos.vn' } = process.env;

const api = axios.create({
  baseURL: PAYOS_BASE_URL,
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json',
    'x-client-id': PAYOS_CLIENT_ID,
    'x-api-key': PAYOS_API_KEY
  }
});

export function signCreatePayment({ amount, cancelUrl, description, orderCode, returnUrl }) {
  const data = `amount=${amount}&cancelUrl=${encodeURI(cancelUrl)}&description=${encodeURI(description)}&orderCode=${orderCode}&returnUrl=${encodeURI(returnUrl)}`;
  return crypto.createHmac('sha256', PAYOS_CHECKSUM_KEY).update(data).digest('hex');
}

export async function createPaymentLink(payload) {
  const signature = signCreatePayment(payload);
  const body = { ...payload, signature };
  const res = await api.post('/v2/payment-requests', body);
  return res.data;
}

export async function confirmWebhook(webhookUrl) {
  const res = await api.post('/confirm-webhook', { webhookUrl });
  return res.data;
}