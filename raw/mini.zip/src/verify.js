import crypto from 'crypto';
const { PAYOS_CHECKSUM_KEY } = process.env;

export function verifyWebhookSignature({ data, signature }) {
  const keys = Object.keys(data || {}).sort();
  const encoded = keys.map(k => `${k}=${encodeURI(data[k] ?? '')}`).join('&');
  const expected = crypto.createHmac('sha256', PAYOS_CHECKSUM_KEY).update(encoded).digest('hex');
  return expected === signature;
}