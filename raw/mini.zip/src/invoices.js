import crypto from 'crypto';
import PDFDocument from 'pdfkit';
import { orderStatus } from './memoryStore.js';

export const invoiceStore = new Map();
function genId() { return 'inv_' + crypto.randomBytes(8).toString('hex'); }
function calcTotal(items=[]) { return items.reduce((s,it)=>s+Number(it.qty)*Number(it.unitPrice),0); }

export function createInvoice({ orderCode,buyer,items,note,currency='VND' }) {
  if(!orderCode||!Array.isArray(items)||!items.length) throw new Error('orderCode và items là bắt buộc');
  const statusKnown = orderStatus.get(Number(orderCode));
  const paid = !!statusKnown?.payload?.success;
  const inv = { id:genId(), orderCode:Number(orderCode), buyer:buyer||{}, items, note:note||'', currency,
    total:calcTotal(items), status: paid?'issued':'draft', createdAt:new Date().toISOString() };
  invoiceStore.set(inv.id,inv);
  return inv;
}
export function getInvoice(id){ const inv=invoiceStore.get(id); if(!inv) throw new Error('Invoice not found'); return inv; }
export function renderInvoicePdf(inv,res){
  const doc=new PDFDocument({size:'A4',margin:40}); res.setHeader('Content-Type','application/pdf'); doc.pipe(res);
  doc.fontSize(18).text('HOÁ ĐƠN BÁN HÀNG',{align:'center'}).moveDown(0.5);
  doc.fontSize(10).text(`Mã hóa đơn: ${inv.id}`).text(`Mã đơn hàng: ${inv.orderCode}`).text(`Ngày tạo: ${inv.createdAt}`).moveDown();
  doc.fontSize(12).text('Thông tin người mua',{underline:true});
  doc.fontSize(10).text(`Tên: ${inv.buyer?.name||''}`);
  if(inv.buyer?.email) doc.text(`Email: ${inv.buyer.email}`);
  if(inv.buyer?.taxCode) doc.text(`MST: ${inv.buyer.taxCode}`);
  doc.moveDown().fontSize(12).text('Chi tiết hàng hóa',{underline:true}).moveDown(0.3);
  inv.items.forEach((it,i)=>doc.fontSize(10).text(`${i+1}. ${it.name} x${it.qty} @ ${it.unitPrice.toLocaleString()} ${inv.currency}`));
  doc.moveDown().fontSize(12).text(`Tổng cộng: ${inv.total.toLocaleString()} ${inv.currency}`,{align:'right'});
  if(inv.note) doc.moveDown().fontSize(10).text(`Ghi chú: ${inv.note}`);
  doc.end();
}