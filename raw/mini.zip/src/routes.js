import express from 'express';
import QRCode from 'qrcode';
import { createPaymentLink, confirmWebhook } from './payos.js';
import { verifyWebhookSignature } from './verify.js';
import { orderStatus, sseClients } from './memoryStore.js';
import { createInvoice, getInvoice, renderInvoicePdf } from './invoices.js';

const router = express.Router();

router.get('/health', (_req,res)=>res.json({ok:true,ts:new Date().toISOString()}));

router.post('/api/qr', async (req,res)=>{
 try{
   const {orderCode,amount,description,returnUrl,cancelUrl}=req.body||{};
   if(!orderCode||!amount||!description||!returnUrl||!cancelUrl)
     return res.status(400).json({error:'Missing fields'});
   const payosResp=await createPaymentLink({orderCode,amount,description,returnUrl,cancelUrl});
   const data=payosResp?.data||payosResp; const url=data.checkoutUrl||data.shortLink||data.paymentLink;
   const qr= await QRCode.toDataURL(url);
   res.json({ok:true,payos:payosResp,qr:{url,imageDataUrl:qr}});
 }catch(e){res.status(500).json({ok:false,error:e.message});}
});

router.post('/webhooks/payos', express.json({type:'*/*'}),(req,res)=>{
 const {code,desc,success,data,signature}=req.body||{};
 const okSig=verifyWebhookSignature({data,signature});
 if(!okSig)return res.status(400).json({ok:false,error:'Invalid signature'});
 const orderCode=data?.orderCode;
 orderStatus.set(orderCode,{lastEventAt:Date.now(),payload:{code,desc,success,data}});
 const event=JSON.stringify({type:'payos_event',orderCode,success,code,desc,data});
 for(const c of sseClients)c.write(`event: payos\ndata: ${event}\n\n`);
 res.json({ok:true});
});

router.get('/events',(req,res)=>{res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache'});
res.write('event:hello\ndata:'+JSON.stringify({t:Date.now()})+'\n\n');sseClients.add(res);req.on('close',()=>sseClients.delete(res));});

router.get('/status/:orderCode',(req,res)=>{const oc=Number(req.params.orderCode);res.json(orderStatus.get(oc)||{ok:false});});

router.post('/admin/confirm-webhook',async(req,res)=>{
 try{const {webhookUrl}=req.body;const r=await confirmWebhook(webhookUrl);res.json(r);}catch(e){res.status(500).json({ok:false,error:e.message});}
});

// Invoices
router.post('/api/invoices',(req,res)=>{try{const inv=createInvoice(req.body||{});res.json({ok:true,invoice:{...inv,pdfUrl:`/api/invoices/${inv.id}/pdf`}});}catch(e){res.status(400).json({ok:false,error:e.message});}});
router.get('/api/invoices/:id',(req,res)=>{try{const inv=getInvoice(req.params.id);res.json({ok:true,invoice:inv});}catch(e){res.status(404).json({ok:false,error:e.message});}});
router.get('/api/invoices/:id/pdf',(req,res)=>{try{const inv=getInvoice(req.params.id);renderInvoicePdf(inv,res);}catch(e){res.status(404).json({ok:false,error:e.message});}});

export default router;