import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import morgan from 'morgan';
import cors from 'cors';
import routes from './routes.js';
import fs from 'fs';

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

const startedAt = new Date();

app.get('/', (_req, res) => {
  const upSec = process.uptime();
  const up = {
    startedAt: startedAt.toISOString(),
    uptimeSeconds: Math.floor(upSec),
    memoryMB: Math.round(process.memoryUsage().rss / 1024 / 1024)
  };

  res.type('html').send(`<!doctype html>
  <html lang="vi"><head><meta charset="utf-8" /><title>payOS mini service</title></head>
  <body>
  <h1>payOS mini service</h1>
  <p>Uptime: ${up.uptimeSeconds}s, Started: ${up.startedAt}, Mem: ${up.memoryMB}MB</p>
  <p>Xem docs ở <a href="/openapi.json">/openapi.json</a></p>
  </body></html>`);
});

app.get('/openapi.json', (_req, res) => {
  const spec = JSON.parse(fs.readFileSync(new URL('./openapi.json', import.meta.url)));
  res.json(spec);
});

app.use(routes);

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server running at http://localhost:${port}`));
