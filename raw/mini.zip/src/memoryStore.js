export const orderStatus = new Map();
export const sseClients = new Set();