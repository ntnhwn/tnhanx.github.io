const fse = require('fs-extra');
const path = require('path');
const DATA_FILE = path.join(__dirname, '..', 'data', 'thanhtoan.json');

async function ensureFile() {
  await fse.ensureFile(DATA_FILE);
  const raw = await fse.readFile(DATA_FILE, 'utf8').catch(() => '');
  if (!raw) await fse.writeFile(DATA_FILE, JSON.stringify({ payments: [] }, null, 2));
}
async function readAll() {
  await ensureFile();
  const json = await fse.readJson(DATA_FILE);
  return json.payments || [];
}
async function writeAll(list) {
  await ensureFile();
  await fse.writeJson(DATA_FILE, { payments: list }, { spaces: 2 });
}
async function upsert(record) {
  const list = await readAll();
  const idx = list.findIndex(x => String(x.orderCode) === String(record.orderCode));
  if (idx >= 0) list[idx] = { ...list[idx], ...record };
  else list.unshift(record);
  await writeAll(list);
  return record;
}
async function getByOrderCode(orderCode) {
  const list = await readAll();
  return list.find(x => String(x.orderCode) === String(orderCode));
}
module.exports = { readAll, upsert, getByOrderCode };