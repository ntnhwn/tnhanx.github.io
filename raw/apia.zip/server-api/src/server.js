require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const payos = require('./payos');
const storage = require('./storage');
const notifier = require('./notifier');
const app = express();
app.use(cors());
app.use(express.json({ type: '*/*' }));
const PORT = process.env.PORT || 3000;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;

app.post('/api/thanhtoan/create', async (req, res) => {
  try {
    const { amount, description, userId } = req.body;
    if (!amount || Number(amount) <= 0) return res.status(400).json({ error: 'amount không hợp lệ' });
    const orderCode = Date.now();
    const returnUrl = `${BASE_URL}/api/thanhtoan/return?orderCode=${orderCode}`;
    const cancelUrl = `${BASE_URL}/api/thanhtoan/cancel?orderCode=${orderCode}`;
    const webhookUrl = `${BASE_URL}/api/thanhtoan/webhook`;
    const link = await payos.createPaymentLink({
      orderCode, amount: Number(amount), description: description || `Thanh toán #${orderCode}`,
      returnUrl, cancelUrl, items: [], buyerName: userId ? String(userId) : undefined, metadata: { userId, webhookUrl }
    });
    const payUrl = link.checkoutUrl || link.paymentLink || link.shortLink;
    await storage.upsert({ id: uuidv4(), orderCode, amount: Number(amount), description: description || '', userId: userId || null, status: 'PENDING', payUrl, createdAt: new Date().toISOString() });
    res.json({ orderCode, amount: Number(amount), status: 'PENDING', payUrl });
  } catch (e) {
    console.error('Create error:', e);
    res.status(500).json({ error: 'Tạo thanh toán thất bại', detail: String(e.message || e) });
  }
});
app.get('/api/thanhtoan/history', async (_req, res) => res.json(await storage.readAll()));
app.get('/api/thanhtoan/status/:orderCode', async (req, res) => {
  const item = await storage.getByOrderCode(req.params.orderCode);
  if (!item) return res.status(404).json({ error: 'Không tìm thấy orderCode' });
  res.json(item);
});
app.post('/api/thanhtoan/webhook', async (req, res) => {
  try {
    const data = payos.verifyWebhookData(req.body);
    const orderCode = data.orderCode || data.data?.orderCode;
    const amount = data.amount || data.data?.amount;
    const description = data.description || data.data?.description || '';
    const statusRaw = (data.code || data.status || data.data?.status || '').toUpperCase();
    const userId = data.metadata?.userId || null;
    const status = statusRaw === 'SUCCESS' ? 'PAID' : (statusRaw === 'CANCELLED' || statusRaw === 'FAILED') ? statusRaw : 'UNKNOWN';
    const existed = await storage.getByOrderCode(orderCode);
    await storage.upsert({ ...(existed || { id: uuidv4(), createdAt: new Date().toISOString() }), orderCode, amount, description, userId: existed?.userId ?? userId ?? null, status, paidAt: status === 'PAID' ? new Date().toISOString() : (existed?.paidAt || null), raw: data });
    if (status === 'PAID') await notifier.onPaid({ orderCode, amount, description, userId });
    if (status === 'CANCELLED' || status === 'FAILED') await notifier.onCanceled({ orderCode, userId });
    res.json({ ok: true });
  } catch (e) {
    console.error('Webhook verify/update error:', e);
    res.status(400).json({ ok: false, error: 'Webhook not verified' });
  }
});
app.get('/api/thanhtoan/return', (_req, res) => res.send('Thanh toán thành công.'));
app.get('/api/thanhtoan/cancel', (_req, res) => res.send('Bạn đã huỷ thanh toán.'));
app.listen(PORT, () => console.log(`API run: http://localhost:${PORT}`));