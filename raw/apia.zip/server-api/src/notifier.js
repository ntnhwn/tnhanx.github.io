module.exports = {
  async onPaid({ orderCode, amount, description, userId }) {
    console.log(`[NOTIFY] ✅ Paid: order=${orderCode} amount=${amount} user=${userId} "${description||''}"`);
  },
  async onCanceled({ orderCode, userId }) {
    console.log(`[NOTIFY] ❌ Canceled/Failed: order=${orderCode} user=${userId}`);
  }
};