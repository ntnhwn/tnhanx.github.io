const axios = require('axios');
const API_BASE = process.env.THANHTOAN_API_BASE || 'http://localhost:3000/api/thanhtoan';

async function getStreamFromURL(url) {
  const res = await axios.get(url, { responseType: 'stream', timeout: 15000 });
  return res.data;
}

module.exports.config = {
  name: "thanhtoan",
  version: "1.2.0",
  hasPermssion: 0,
  credits: "you",
  description: "Tạo link PayOS + gửi ảnh VietQR",
  commandCategory: "tài chính",
  usages: "[tạo|lịch_sử|trạng_thái]",
  cooldowns: 3
};

module.exports.run = async function({ api, event, args }) {
  const reply = (msg) => api.sendMessage(msg, event.threadID, event.messageID);
  const sub = (args[0] || '').toLowerCase();

  if (["tạo","tao","create"].includes(sub)) {
    const amount = Number(args[1]);
    if (!amount || amount <= 0)
      return reply("Vui lòng nhập: thanhtoan tạo <số tiền> <mô tả...>");
    const description = (args.slice(2).join(' ') || 'Thanh toán').trim();

    try {
      const body = { amount, description, userId: `${event.senderID}` };
      const res = await axios.post(`${API_BASE}/create`, body, { timeout: 15000 });
      const { orderCode, payUrl, qrCode, qrPngUrl } = res.data;

      const qrImgUrl = qrPngUrl || qrCode || payUrl;

      const msg = {
        body:
          "⏳ Nhóm đang chờ thanh toán.\n" +
          `💵 Số tiền: ${amount}đ\n` +
          `📝 Nội dung: ${description}\n` +
          `🔗 Link: ${payUrl}\n` +
          `🆔 Mã đơn: ${orderCode}`,
        attachment: await getStreamFromURL(qrImgUrl)
      };
      return api.sendMessage(msg, event.threadID, event.messageID);
    } catch (e) {
      console.error(e);
      return reply("Không tạo được link thanh toán. Kiểm tra API.");
    }
  }

  if (["lịch_sử","lich_su","history"].includes(sub)) {
    try {
      const res = await axios.get(`${API_BASE}/history`, { timeout: 15000 });
      const list = Array.isArray(res.data) ? res.data : [];
      if (!list.length) return reply("Chưa có giao dịch nào.");
      const mine = list.filter(it => !it.userId || it.userId === String(event.senderID));
      const show = (mine.length ? mine : list).slice(0, 10);
      const lines = show.map(x =>
        `• [${x.status}] ${x.amount}đ | order=${x.orderCode} | ${x.description || ''} | ${new Date(x.createdAt).toLocaleString()}`
      );
      return reply("Lịch sử gần đây:\n" + lines.join("\n"));
    } catch (e) {
      console.error(e);
      return reply("Không lấy được lịch sử. Kiểm tra API.");
    }
  }

  if (["trạng_thái","trang_thai","status"].includes(sub)) {
    const orderCode = args[1];
    if (!orderCode) return reply("Cú pháp: thanhtoan trạng_thái <orderCode>");
    try {
      const res = await axios.get(`${API_BASE}/status/${orderCode}`, { timeout: 15000 });
      const it = res.data;
      const msg =
        `Trạng thái đơn ${orderCode}: ${it.status}\n` +
        `Số tiền: ${it.amount}đ\n` +
        (it.payUrl ? `Link: ${it.payUrl}\n` : '') +
        (it.paidAt ? `Thanh toán lúc: ${new Date(it.paidAt).toLocaleString()}` : '');
      return reply(msg);
    } catch (e) {
      if (e.response && e.response.status === 404) return reply("Không tìm thấy orderCode.");
      console.error(e);
      return reply("Không tra cứu được trạng thái. Kiểm tra API.");
    }
  }

  return reply(
    "Cách dùng:\n" +
    "• thanhtoan tạo <số_tiền> <mô tả>\n" +
    "• thanhtoan lịch_sử\n" +
    "• thanhtoan trạng_thái <orderCode>"
  );
};