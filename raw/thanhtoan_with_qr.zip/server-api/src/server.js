require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const QRCode = require('qrcode');

const payos = require('./payos');
const storage = require('./storage');
const notifier = require('./notifier');

const app = express();
app.use(cors());
app.use(express.json({ type: '*/*' }));

const PORT = process.env.PORT || 3000;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;

// ======= API tạo link thanh toán =======
app.post('/api/thanhtoan/create', async (req, res) => {
  try {
    const { amount, description, userId } = req.body;
    if (!amount || Number(amount) <= 0)
      return res.status(400).json({ error: 'amount không hợp lệ' });

    const orderCode = Date.now(); // unique
    const returnUrl = `${BASE_URL}/api/thanhtoan/return?orderCode=${orderCode}`;
    const cancelUrl = `${BASE_URL}/api/thanhtoan/cancel?orderCode=${orderCode}`;

    // Thay vì metadata, ta chèn userId vào description để webhook đọc được
    const descFull = `[user:${userId || 'unknown'}] ${description || 'Thanh toán'}`;

    const link = await payos.createPaymentLink({
      orderCode,
      amount: Number(amount),
      description: descFull,
      returnUrl,
      cancelUrl,
      items: [],
      buyerName: userId ? String(userId) : undefined
    });

    const payUrl = link.checkoutUrl || link.paymentLink || link.shortLink;
    const qrFromPayOS = link.qrCode; // nếu SDK trả sẵn

    await storage.upsert({
      id: uuidv4(),
      orderCode,
      amount: Number(amount),
      description: descFull,
      userId: userId || null,
      status: 'PENDING',
      payUrl,
      qrCode: qrFromPayOS || null,
      createdAt: new Date().toISOString()
    });

    // Trả thêm URL ảnh QR PNG do server render
    const qrPngUrl = `${BASE_URL}/api/thanhtoan/qr/${orderCode}.png`;

    res.json({ orderCode, amount: Number(amount), status: 'PENDING', payUrl, qrCode: qrFromPayOS || null, qrPngUrl });
  } catch (e) {
    console.error('Create error:', e);
    res.status(500).json({ error: 'Tạo thanh toán thất bại', detail: String(e.message || e) });
  }
});

// ======= API render PNG QR từ payUrl =======
app.get('/api/thanhtoan/qr/:orderCode.png', async (req, res) => {
  try {
    const it = await storage.getByOrderCode(req.params.orderCode);
    if (!it?.payUrl) return res.status(404).send('Not found');
    res.set('Content-Type', 'image/png');
    QRCode.toFileStream(res, it.payUrl);
  } catch (e) {
    console.error('QR render error:', e);
    res.status(500).send('QR error');
  }
});

// ======= API xem lịch sử =======
app.get('/api/thanhtoan/history', async (_req, res) => {
  res.json(await storage.readAll());
});

// ======= API xem trạng thái đơn =======
app.get('/api/thanhtoan/status/:orderCode', async (req, res) => {
  const item = await storage.getByOrderCode(req.params.orderCode);
  if (!item) return res.status(404).json({ error: 'Không tìm thấy orderCode' });
  res.json(item);
});

// ======= Webhook PayOS =======
app.post('/api/thanhtoan/webhook', async (req, res) => {
  try {
    const data = payos.verifyWebhookData(req.body);
    const orderCode = data.orderCode || data.data?.orderCode;
    const amount = data.amount || data.data?.amount;
    const description = data.description || data.data?.description || '';
    const statusRaw = (data.code || data.status || data.data?.status || '').toUpperCase();

    // Parse userId từ description nếu có dạng [user:xxxxx]
    const userMatch = description.match(/\[user:(.*?)\]/);
    const userId = userMatch ? userMatch[1] : null;

    const status =
      statusRaw === 'SUCCESS'
        ? 'PAID'
        : statusRaw === 'CANCELLED' || statusRaw === 'FAILED'
        ? statusRaw
        : 'UNKNOWN';

    const existed = await storage.getByOrderCode(orderCode);
    await storage.upsert({
      ...(existed || { id: uuidv4(), createdAt: new Date().toISOString() }),
      orderCode,
      amount,
      description,
      userId: existed?.userId ?? userId ?? null,
      status,
      paidAt:
        status === 'PAID' ? new Date().toISOString() : existed?.paidAt || null,
      raw: data
    });

    if (status === 'PAID') await notifier.onPaid({ orderCode, amount, description, userId });
    if (status === 'CANCELLED' || status === 'FAILED')
      await notifier.onCanceled({ orderCode, userId });

    res.json({ ok: true });
  } catch (e) {
    console.error('Webhook verify/update error:', e);
    res.status(400).json({ ok: false, error: 'Webhook not verified' });
  }
});

// ======= Return / Cancel endpoints =======
app.get('/api/thanhtoan/return', (_req, res) =>
  res.send('Thanh toán thành công.')
);
app.get('/api/thanhtoan/cancel', (_req, res) =>
  res.send('Bạn đã huỷ thanh toán.')
);

// ======= Start server =======
app.listen(PORT, () => {
  console.log(`API run: http://localhost:${PORT}`);
  console.log(`Webhook: ${BASE_URL}/api/thanhtoan/webhook`);
});