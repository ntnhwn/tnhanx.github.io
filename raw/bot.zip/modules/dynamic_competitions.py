from utils.football_api import get_live_matches_by_competition, get_all_competitions

user_preferences = {}

def set_user_preference(user_id, competition_id):
    user_preferences[user_id] = competition_id

def get_user_preference(user_id):
    return user_preferences.get(user_id)

def get_competition_events(competition_id, competition_name):
    data = get_live_matches_by_competition(competition_id)
    if not data or not data.get("matches"):
        return f"⏱ Không có trận {competition_name} đang diễn ra."
    text = f"⚽ {competition_name} (LIVE):\n"
    for match in data['matches']:
        h = match['homeTeam']['name']
        a = match['awayTeam']['name']
        s = match['score']['fullTime']
        text += f"{h} {s['home']} - {s['away']} {a}\n"
    return text
