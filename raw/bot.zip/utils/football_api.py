import os
import requests

def get_live_matches_by_competition(competition_id):
    token = os.getenv("FOOTBALL_DATA_API_KEY")
    url = f"https://api.football-data.org/v4/competitions/{competition_id}/matches?status=LIVE"
    headers = {'X-Auth-Token': token}
    try:
        res = requests.get(url, headers=headers)
        if res.status_code == 200:
            return res.json()
    except:
        pass
    return None

def get_all_competitions():
    token = os.getenv("FOOTBALL_DATA_API_KEY")
    url = "https://api.football-data.org/v4/competitions"
    headers = {'X-Auth-Token': token}
    try:
        res = requests.get(url, headers=headers)
        if res.status_code == 200:
            return res.json().get("competitions", [])
    except:
        pass
    return []
