import os
import logging
import threading
import time
import requests
from dotenv import load_dotenv
from telegram import Update, Bot
from telegram.ext import Updater, CommandHandler, CallbackContext
from modules.dynamic_competitions import (
    get_all_competitions, get_competition_events, user_preferences,
    set_user_preference, get_user_preference
)
from utils.football_api import get_live_matches_by_competition

load_dotenv()
logging.basicConfig(level=logging.INFO)

prev_scores = {}

def monitor_matches(bot: Bot):
    while True:
        for user_id, comp_id in user_preferences.items():
            data = get_live_matches_by_competition(comp_id)
            if not data or not data.get("matches"):
                continue
            for match in data["matches"]:
                match_id = match["id"]
                score = match["score"]["fullTime"]
                key = f"{match_id}_{score['home']}-{score['away']}"
                if match_id not in prev_scores or prev_scores[match_id] != key:
                    prev_scores[match_id] = key
                    h = match["homeTeam"]["name"]
                    a = match["awayTeam"]["name"]
                    text = f"⚽ BÀN THẮNG!
{h} {score['home']} - {score['away']} {a}"
                    try:
                        bot.send_message(chat_id=user_id, text=text)
                    except Exception as e:
                        print(f"[!] Gửi thất bại: {e}")
        time.sleep(60)

def start(update: Update, context: CallbackContext):
    update.message.reply_text("⚽ Chào mừng đến với Bot Bóng đá!
Dùng /help để xem hướng dẫn.")

def help_command(update: Update, context: CallbackContext):
    update.message.reply_text(
        "📌 Lệnh hỗ trợ:
"
        "/setgiaidau <CODE> - Chọn giải (VD: PL, CL, SA,...)
"
        "/trandau - Xem trận đấu đang diễn ra của giải đã chọn
"
        "/thoitiet <thành phố>
"
        "/stats - Thống kê bot
"
        "/premium - Tính năng cao cấp"
    )

def weather(update: Update, context: CallbackContext):
    if not context.args:
        update.message.reply_text("❗ Vui lòng nhập tên thành phố.")
        return
    city = " ".join(context.args)
    api_key = os.getenv("OWM_API_KEY")
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric&lang=vi"
    res = requests.get(url)
    if res.status_code != 200:
        update.message.reply_text("Không tìm thấy thông tin thời tiết.")
        return
    data = res.json()
    desc = data['weather'][0]['description']
    temp = data['main']['temp']
    feels = data['main']['feels_like']
    humid = data['main']['humidity']
    update.message.reply_text(f"🌤 {city.title()}:
{desc}, {temp}°C (cảm giác {feels}°C), ẩm {humid}%")

def stats(update: Update, context: CallbackContext):
    update.message.reply_text("📊 Người dùng: 999
👥 Nhóm: 100")

def premium(update: Update, context: CallbackContext):
    update.message.reply_text("💎 Premium: Nhận thông báo bàn thắng, ưu tiên cập nhật. Liên hệ admin để nâng cấp.")

def set_giaidau(update: Update, context: CallbackContext):
    if not context.args:
        update.message.reply_text("❗ Vui lòng nhập mã giải đấu. (VD: PL, CL, SA, etc.)")
        return
    code = context.args[0].upper()
    competitions = get_all_competitions()
    comp = next((c for c in competitions if c['code'] == code), None)
    if comp:
        set_user_preference(update.effective_user.id, comp['id'])
        update.message.reply_text(f"✅ Đã chọn giải: {comp['name']}")
    else:
        update.message.reply_text("❌ Mã giải không hợp lệ.")

def trandau(update: Update, context: CallbackContext):
    user_id = update.effective_user.id
    comp_id = get_user_preference(user_id)
    if not comp_id:
        update.message.reply_text("❗ Bạn chưa chọn giải đấu. Dùng /setgiaidau <CODE>")
        return
    competitions = get_all_competitions()
    comp = next((c for c in competitions if c['id'] == comp_id), None)
    if comp:
        update.message.reply_text(get_competition_events(comp_id, comp['name']))
    else:
        update.message.reply_text("❌ Không tìm thấy giải đấu.")

def main():
    token = os.getenv("TELEGRAM_TOKEN")
    updater = Updater(token, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CommandHandler("help", help_command))
    dp.add_handler(CommandHandler("thoitiet", weather))
    dp.add_handler(CommandHandler("stats", stats))
    dp.add_handler(CommandHandler("premium", premium))
    dp.add_handler(CommandHandler("setgiaidau", set_giaidau))
    dp.add_handler(CommandHandler("trandau", trandau))

    # Bắt đầu luồng tự động cập nhật trận đấu
    threading.Thread(target=monitor_matches, args=(updater.bot,), daemon=True).start()

    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()
