const chalk = require('chalk');

// Hàm chuyển đổi mã hex sang RGB
function hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

// Hàm nội suy màu giữa hai màu
function interpolateColor(color1, color2, factor) {
    const rgb1 = hexToRgb(color1);
    const rgb2 = hexToRgb(color2);

    if (!rgb1 || !rgb2) return '#000000';

    const r = Math.round(rgb1.r + factor * (rgb2.r - rgb1.r));
    const g = Math.round(rgb1.g + factor * (rgb2.g - rgb1.g));
    const b = Math.round(rgb1.b + factor * (rgb2.b - rgb1.b));

    return `#${(1 << 24 | r << 16 | g << 8 | b).toString(16).slice(1)}`;
}

// Hàm tạo gradient cho một đoạn text
function createLineGradient(text, colors) {
    const chars = text.split('');
    let result = '';
    const totalChars = chars.length;

    chars.forEach((char, i) => {
        const section = (i / totalChars) * (colors.length - 1);
        const colorIndex = Math.floor(section);
        const factor = section - colorIndex;

        const color = interpolateColor(
            colors[colorIndex],
            colors[colorIndex + 1] || colors[colorIndex],
            factor
        );
        result += chalk.hex(color)(char);
    });

    return result;
}

module.exports.config = {
    name: "console",
    version: "1.3.0",
    hasPermssion: 3,
    credits: "JRT modified by Satoru",
    description: "Bật/tắt ghi log console với gradient",
    commandCategory: "Hệ thống",
    usages: "[on/off]",
    cooldowns: 5,
};

module.exports.handleEvent = async function ({ api, args, Users, event, Threads, utils, client }) {
    const { threadID, messageID, senderID, isGroup, body } = event;

    // Khởi tạo global.data nếu chưa có
    if (!global.data) global.data = {};
    if (!global.data.console) return;

    const gradientColors = [
        ['#FF6B6B', '#4ECDC4'],
        ['#A8E6CF', '#FFD3A5'],
        ['#FFA07A', '#98FB98'],
        ['#87CEEB', '#DDA0DD'],
        ['#F0E68C', '#FFA500']
    ];

    const randomColors = gradientColors[Math.floor(Math.random() * gradientColors.length)];

    const userName = global.data.userName.get(senderID) || await Users.getNameUser(senderID);
    const threadName = isGroup ? (global.data.threadInfo.get(threadID) || {}).threadName || "Unknown Group" : "Private Chat";

    const time = new Date().toLocaleString('vi-VN', { 
        timeZone: 'Asia/Ho_Chi_Minh',
        hour12: false 
    });

    const topBorder = "╔════════════════════════════════════════════════════════════════════╗";
    const bottomBorder = "╚════════════════════════════════════════════════════════════════════╝";
    const line = "║";

    function truncate(str, maxLength) {
        return str.length > maxLength ? str.substring(0, maxLength - 3) + "..." : str;
    }

    if (body && body.length > 0) {
        console.log(createLineGradient(topBorder, randomColors));
        console.log(createLineGradient(`${line} Người gửi: ${truncate(userName, 50)}`, randomColors));
        console.log(createLineGradient(`${line} Nhóm: ${truncate(threadName, 54)}`, randomColors));
        console.log(createLineGradient(`${line} Tin nhắn: ${truncate(body, 54)}`, randomColors));
        console.log(createLineGradient(`${line} Thời gian: ${truncate(time, 52)}`, randomColors));
        console.log(createLineGradient(`${line} ID: ${truncate(senderID, 58)}`, randomColors));
        console.log(createLineGradient(bottomBorder, randomColors));
    }
};

module.exports.run = async function ({ api, args, Users, event, Threads, utils, client }) {
    const { threadID, messageID } = event;

    if (args.length === 0) {
        return api.sendMessage("Vui lòng sử dụng on hoặc off.", threadID, messageID);
    }

    const action = args[0].toLowerCase();

    // Khởi tạo global.data nếu chưa có
    if (!global.data) global.data = {};
    
    if (action === "on") {
        global.data.console = true;
        return api.sendMessage("Đã bật ghi log console với hiệu ứng gradient.", threadID, messageID);
    } else if (action === "off") {
        global.data.console = false;
        return api.sendMessage("Đã tắt ghi log console.", threadID, messageID);
    } else {
        return api.sendMessage("Tham số không hợp lệ. Vui lòng sử dụng 'on' hoặc 'off'.", threadID, messageID);
    }
};