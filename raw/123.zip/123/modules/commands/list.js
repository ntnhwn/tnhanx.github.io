
module.exports.config = {
    name: "list",
    version: "1.0.0",
    hasPermssion: 1,
    credits: "ManhG & manhIT & Gojo",
    description: "Xem danh sách ban, box, bạn bè hoặc người đã rời nhóm",
    commandCategory: "QTV",
    usages: "[ban/box/friend/out] [thread/user/del]",
    cooldowns: 5
};

module.exports.handleReply = async function({
    api,
    args,
    Users,
    handleReply,
    event,
    Threads
}) {
    const { threadID, messageID, senderID } = event;
    
    if (parseInt(senderID) !== parseInt(handleReply.author)) return;

    switch (handleReply.type) {
        case "unbanthread": {
            var arrnum = event.body.split(" ");
            var nums = arrnum.map(n => parseInt(n));
            var msg = "", idMsg = "", nameMsg = "";
            
            for (let num of nums) {
                var info = handleReply.listBanned[num - 1];
                var threadName = info.slice(3);
                let parts = info.split(":");
                const threadId = parts[parts.length - 1].trim();
                
                const threadData = (await Threads.getData(threadId)).data || {};
                threadData.banned = 0;
                threadData.reason = null;
                threadData.dateAdded = null;
                await Threads.setData(threadId, { data: threadData });
                
                global.data.threadBanned.delete(threadId);
                msg += `✅ ${info}\n`;
                idMsg += ` ${threadId}\n`;
                nameMsg += ` ${threadName}\n`;
            }
            
            const userName = await Users.getNameUser(senderID);
            api.sendMessage(`Thông báo từ Admin ${userName}\n──────────────────\n→ Nhóm ${nameMsg} của bạn đã được Gỡ Ban\n→ Có thể sử dụng được bot ngay bây giờ`, idMsg, () => {
                api.sendMessage(`Thực thi Unban thành công\n\n${msg}`, threadID, () => {
                    api.unsendMessage(handleReply.messageID);
                });
            });
            break;
        }

        case "unbanuser": {
            var arrnum = event.body.split(" ");
            var nums = arrnum.map(n => parseInt(n));
            var msg = "", idMsg = "", nameMsg = "";
            
            for (let num of nums) {
                var info = handleReply.listBanned[num - 1];
                var userName = info.slice(3);
                let parts = info.split(":");
                const userId = parts[parts.length - 1].trim();
                
                const userData = (await Users.getData(userId)).data || {};
                userData.banned = 0;
                userData.reason = null;
                userData.dateAdded = null;
                await Users.setData(userId, { data: userData });
                
                global.data.userBanned.delete(userId);
                msg += `✅ ${info}\n`;
                idMsg += ` ${userId}\n`;
                nameMsg += ` ${userName}\n`;
            }
            
            api.sendMessage(`Thực thi Unban thành công\n\n${msg}`, threadID, () => {
                api.unsendMessage(handleReply.messageID);
            });
            break;
        }

        case "boxreply": {
            var arg = event.body.split(" ");
            var idgr = handleReply.groupid[arg[1] - 1];

            if (arg[0] == "ban" || arg[0] == "Ban") {
                const data = (await Threads.getData(idgr)).data || {};
                data.banned = 1;
                await Threads.setData(idgr, { data });
                global.data.threadBanned.set(parseInt(idgr), 1);
                api.sendMessage(`[ 𝗠𝗢𝗗𝗘 ] → Đã ban thành công nhóm\n→ TID: ${idgr}`, threadID, messageID);
            } else if (arg[0] == "unban" || arg[0] == "Unban") {
                const data = (await Threads.getData(idgr)).data || {};
                data.banned = 0;
                await Threads.setData(idgr, { data });
                global.data.threadBanned.delete(parseInt(idgr));
                api.sendMessage(`[ 𝗠𝗢𝗗𝗘 ] → Đã gỡ ban thành công cho nhóm\n→ TID: ${idgr}`, threadID, messageID);
            } else if (arg[0] == "out" || arg[0] == "Out") {
                api.removeUserFromGroup(`${api.getCurrentUserID()}`, idgr);
                api.sendMessage("[ 𝗠𝗢𝗗𝗘 ] → Đã out nhóm có ID: " + idgr, threadID, messageID);
            }
            break;
        }

        case "friendreply": {
            var arrnum = event.body.split(" ");
            var nums = arrnum.map(n => parseInt(n));
            var msg = "";
            
            for (let num of nums) {
                const name = handleReply.nameUser[num - 1];
                const urlUser = handleReply.urlUser[num - 1];
                const uidUser = handleReply.uidUser[num - 1];

                api.unfriend(uidUser);
                msg += `- ${name}\n🌐ProfileUrl: ${urlUser}\n`;
            }

            api.sendMessage(`💢Thực thi xoá bạn bè💢\n\n${msg}`, threadID, () => {
                api.unsendMessage(handleReply.messageID);
            });
            break;
        }
    }
};

module.exports.run = async function({ event, api, args, Users, Threads }) {
    const { threadID, messageID, senderID } = event;
    
    if (!args[0]) {
        return api.sendMessage("Vui lòng chọn:\n• list ban [thread/user] - Xem danh sách ban\n• list box - Xem danh sách nhóm\n• list friend - Xem danh sách bạn bè\n• list out [del] - Xem/xóa danh sách người rời nhóm", threadID, messageID);
    }

    switch (args[0].toLowerCase()) {
        case "ban": {
            if (event.senderID != global.config.NDH[0]) {
                return api.sendMessage("Chỉ admin mới có thể sử dụng lệnh này!", threadID, messageID);
            }

            var listDisplay = [];
            var listBanned = [];
            var i = 1;

            switch (args[1]) {
                case "thread":
                case "t":
                case "-t": {
                    const threadBannedKeys = global.data.threadBanned.keys();
                    for (const threadId of threadBannedKeys) {
                        const threadName = await global.data.threadInfo.get(threadId)?.threadName || "Tên không tồn tại";
                        const reason = await global.data.threadBanned.get(threadId).reason;
                        const dateAdded = await global.data.threadBanned.get(threadId).dateAdded;
                        
                        listBanned.push(`${i++}. ${threadName}\n→ TID: ${threadId}`);
                        listDisplay.push(`${i-1}. ${threadName}\n→ TID: ${threadId}\n→ Lý do: ${reason}\n→ Time: ${dateAdded}`);
                    }

                    if (listDisplay.length === 0) {
                        return api.sendMessage("Hiện tại không có nhóm nào bị ban!", threadID, messageID);
                    }

                    return api.sendMessage(`Hiện tại đang có ${listDisplay.length} nhóm bị ban\n\n${listDisplay.join("\n\n")}\n──────────────────\nReply tin nhắn này + số thứ tự, có thể rep nhiều số, cách nhau bằng dấu cách để unban thread tương ứng`, threadID, (e, info) => {
                        global.client.handleReply.push({
                            name: this.config.name,
                            messageID: info.messageID,
                            author: senderID,
                            type: "unbanthread",
                            listBanned: listBanned
                        });
                    }, messageID);
                }

                case "user":
                case "u":
                case "-u": {
                    const userBannedKeys = global.data.userBanned.keys();
                    for (const userId of userBannedKeys) {
                        const userName = global.data.userName.get(userId) || await Users.getNameUser(userId);
                        const reason = await global.data.userBanned.get(userId).reason;
                        const dateAdded = await global.data.userBanned.get(userId).dateAdded;
                        
                        listBanned.push(`${i++}. ${userName}\n→ UID: ${userId}`);
                        listDisplay.push(`${i-1}. ${userName}\n→ UID: ${userId}\n→ Lý do: ${reason}\n→ Time: ${dateAdded}`);
                    }

                    if (listDisplay.length === 0) {
                        return api.sendMessage("Hiện tại không có người dùng bị ban", threadID, messageID);
                    }

                    return api.sendMessage(`Hiện tại đang có ${listDisplay.length} người dùng bị ban\n\n${listDisplay.join("\n\n")}\n──────────────────\nReply tin nhắn này + số thứ tự, có thể rep nhiều số, cách nhau bằng dấu cách để unban user tương ứng`, threadID, (e, info) => {
                        global.client.handleReply.push({
                            name: this.config.name,
                            messageID: info.messageID,
                            author: senderID,
                            type: "unbanuser",
                            listBanned: listBanned
                        });
                    }, messageID);
                }

                default:
                    return api.sendMessage("Vui lòng chọn: list ban [thread/user]", threadID, messageID);
            }
            break;
        }

        case "box": {
            if (event.senderID != global.config.NDH[0]) {
                return api.sendMessage("Chỉ admin mới có thể sử dụng lệnh này!", threadID, messageID);
            }

            var inbox = await api.getThreadList(100, null, ['INBOX']);
            let list = [...inbox].filter(group => group.isSubscribed && group.isGroup);
            var listthread = [];

            for (var groupInfo of list) {
                let data = await api.getThreadInfo(groupInfo.threadID);
                listthread.push({
                    id: groupInfo.threadID,
                    name: groupInfo.name,
                    sotv: data.userInfo.length,
                    qtv: data.adminIDs.length,
                    messageCount: groupInfo.messageCount,
                });
            }

            var listbox = listthread.sort((a, b) => {
                if (a.sotv > b.sotv) return -1;
                if (a.sotv < b.sotv) return 1;
            });

            let msg = '==== [ Danh Sách Nhóm ] ====\n──────────────────\n';
            let i = 1;
            var groupid = [];
            
            for (var group of listbox) {
                msg += `${i++}. ${group.name}\n→ ID: ${group.id}\n→ Số thành viên: ${group.sotv}\n→ Số quản trị viên: ${group.qtv}\n→ Tổng số tin nhắn: ${group.messageCount}\n──────────────────\n`;
                groupid.push(group.id);
            }

            api.sendMessage(msg + '→ Phản hồi < out/ban/unban + số thứ tự > để out hoặc ban và unban nhóm tương ứng', threadID, (e, data) => {
                global.client.handleReply.push({
                    name: this.config.name,
                    author: senderID,
                    messageID: data.messageID,
                    groupid,
                    type: 'boxreply'
                });
            });
            break;
        }

        case "friend": {
            if (event.senderID != global.config.NDH[0]) {
                return api.sendMessage("Chỉ admin mới có thể sử dụng lệnh này!", threadID, messageID);
            }

            try {
                var listFriend = [];
                var dataFriend = await api.getFriendsList();
                var countFr = dataFriend.length;

                for (var friends of dataFriend) {
                    listFriend.push({
                        name: friends.fullName || "Chưa đặt tên",
                        uid: friends.userID,
                        gender: friends.gender,
                        vanity: friends.vanity,
                        profileUrl: friends.profileUrl
                    });
                }

                var nameUser = [], urlUser = [], uidUser = [];
                var page = parseInt(args[1]) || 1;
                page < 1 ? page = 1 : "";
                var limit = 10;
                var msg = `🎭DS GỒM ${countFr} BẠN BÈ🎭\n\n`;
                var numPage = Math.ceil(listFriend.length / limit);

                for (var i = limit * (page - 1); i < limit * (page - 1) + limit; i++) {
                    if (i >= listFriend.length) break;
                    let infoFriend = listFriend[i];
                    msg += `${i + 1}. ${infoFriend.name}\n🙇‍♂️ID: ${infoFriend.uid}\n🧏‍♂️Gender: ${infoFriend.gender}\n❄️Vanity: ${infoFriend.vanity}\n🌐Profile Url: ${infoFriend.profileUrl}\n\n`;
                    nameUser.push(infoFriend.name);
                    urlUser.push(infoFriend.profileUrl);
                    uidUser.push(infoFriend.uid);
                }

                msg += `✎﹏﹏﹏﹏﹏﹏﹏﹏﹏﹏\n--> Trang ${page}/${numPage} <--\nDùng list friend + số trang\n\n`;

                return api.sendMessage(msg + '🎭Reply số thứ tự(từ 1->10), có thể rep nhiều số, cách nhau bằng dấu cách để xoá bạn bè đó khỏi danh sách!', threadID, (e, data) => {
                    global.client.handleReply.push({
                        name: this.config.name,
                        author: senderID,
                        messageID: data.messageID,
                        nameUser,
                        urlUser,
                        uidUser,
                        type: 'friendreply'
                    });
                });
            } catch (e) {
                return api.sendMessage("Đã xảy ra lỗi khi lấy danh sách bạn bè!", threadID, messageID);
            }
            break;
        }

        case "out": {
            const fs = require("fs-extra");
            const leavePath = __dirname + `/data/leave/${threadID}.json`;

            if (args[1] === 'del') {
                if (!fs.existsSync(leavePath)) {
                    return api.sendMessage("Không có danh sách để xóa.", threadID);
                }
                fs.unlinkSync(leavePath);
                return api.sendMessage("Đã xóa danh sách người rời nhóm thành công.", threadID);
            }

            if (!fs.existsSync(leavePath)) {
                return api.sendMessage("Chưa có ai rời khỏi nhóm.", threadID);
            }

            const leaveData = JSON.parse(fs.readFileSync(leavePath));
            
            if (leaveData.length === 0) {
                return api.sendMessage("Chưa có ai rời khỏi nhóm.", threadID);
            }

            let msg = "❎ Danh sách người đã rời nhóm:\n\n";
            leaveData.forEach((user, index) => {
                msg += `${index + 1}. ${user.name} (ID: ${user.uid})\n`;
                msg += `📅 Thời gian: ${user.time}\n`;
                msg += `🧾 Lý do: ${user.reason}\n`;
                msg += `🔗 Profile: ${user.facebook}\n\n`;
            });

            return api.sendMessage(msg, threadID);
        }

        default:
            return api.sendMessage("Vui lòng chọn:\n• list ban [thread/user] - Xem danh sách ban\n• list box - Xem danh sách nhóm\n• list friend - Xem danh sách bạn bè\n• list out [del] - Xem/xóa danh sách người rời nhóm", threadID, messageID);
    }
};
