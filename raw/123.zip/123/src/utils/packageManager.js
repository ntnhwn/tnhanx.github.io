
const fs = require('fs');
const { execSync, exec } = require('child_process');
const path = require('path');

class PackageManager {
    constructor() {
        this.installedPackages = new Set();
        this.failedPackages = new Set();
        this.builtinModules = require('module').builtinModules;
    }

    // Kiểm tra package có tồn tại không
    isPackageInstalled(packageName) {
        try {
            require.resolve(packageName);
            return true;
        } catch (error) {
            return false;
        }
    }

    // Cài đặt package
    async installPackage(packageName, version = 'latest') {
        return new Promise((resolve, reject) => {
            const installCommand = `npm install ${packageName}${version !== 'latest' ? '@' + version : ''}`;
            
            exec(installCommand, { timeout: 60000 }, (error, stdout, stderr) => {
                if (error) {
                    this.failedPackages.add(packageName);
                    reject(new Error(`Failed to install ${packageName}: ${error.message}`));
                } else {
                    this.installedPackages.add(packageName);
                    resolve({ package: packageName, version, output: stdout });
                }
            });
        });
    }

    // Cài đặt nhiều package cùng lúc
    async installMultiplePackages(packages) {
        const results = [];
        
        for (const pkg of packages) {
            try {
                const result = await this.installPackage(pkg);
                results.push({ success: true, ...result });
            } catch (error) {
                results.push({ success: false, package: pkg, error: error.message });
            }
        }
        
        return results;
    }

    // Phân tích dependencies từ file module
    analyzeDependencies(filePath) {
        try {
            const content = fs.readFileSync(filePath, 'utf8');
            const dependencies = [];
            
            // Tìm tất cả require statements
            const requireRegex = /require\s*\(\s*['"`]([^'"`]+)['"`]\s*\)/g;
            let match;
            
            while ((match = requireRegex.exec(content)) !== null) {
                const packageName = match[1];
                
                // Skip built-in modules, relative paths
                if (!packageName.startsWith('.') && 
                    !packageName.startsWith('/') && 
                    !this.builtinModules.includes(packageName)) {
                    dependencies.push(packageName);
                }
            }
            
            // Tìm dynamic imports
            const importRegex = /import\s*\(\s*['"`]([^'"`]+)['"`]\s*\)/g;
            while ((match = importRegex.exec(content)) !== null) {
                const packageName = match[1];
                if (!packageName.startsWith('.') && 
                    !packageName.startsWith('/') && 
                    !this.builtinModules.includes(packageName)) {
                    dependencies.push(packageName);
                }
            }
            
            return [...new Set(dependencies)]; // Remove duplicates
        } catch (error) {
            return [];
        }
    }

    // Auto check và install cho tất cả modules
    async autoCheckAndInstall(modulesDir = './modules/commands') {
        const report = {
            totalFiles: 0,
            processedFiles: 0,
            installedPackages: [],
            failedPackages: [],
            errors: []
        };

        try {
            const files = fs.readdirSync(modulesDir);
            report.totalFiles = files.filter(file => file.endsWith('.js')).length;

            for (const file of files) {
                if (file.endsWith('.js')) {
                    try {
                        const filePath = path.join(modulesDir, file);
                        const dependencies = this.analyzeDependencies(filePath);
                        
                        for (const dep of dependencies) {
                            if (!this.isPackageInstalled(dep)) {
                                try {
                                    await this.installPackage(dep);
                                    report.installedPackages.push(dep);
                                } catch (error) {
                                    report.failedPackages.push({ package: dep, file, error: error.message });
                                }
                            }
                        }
                        
                        report.processedFiles++;
                    } catch (error) {
                        report.errors.push({ file, error: error.message });
                    }
                }
            }
        } catch (error) {
            report.errors.push({ general: true, error: error.message });
        }

        return report;
    }

    // Kiểm tra và sửa lỗi module cụ thể
    async fixModule(modulePath) {
        try {
            const dependencies = this.analyzeDependencies(modulePath);
            const missingPackages = dependencies.filter(dep => !this.isPackageInstalled(dep));
            
            if (missingPackages.length > 0) {
                const installResults = await this.installMultiplePackages(missingPackages);
                return {
                    success: true,
                    installed: installResults.filter(r => r.success),
                    failed: installResults.filter(r => !r.success)
                };
            }
            
            return { success: true, message: 'No missing dependencies' };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    // Generate báo cáo chi tiết
    generateReport() {
        return {
            installedPackages: Array.from(this.installedPackages),
            failedPackages: Array.from(this.failedPackages),
            totalInstalled: this.installedPackages.size,
            totalFailed: this.failedPackages.size
        };
    }
}

module.exports = PackageManager;
