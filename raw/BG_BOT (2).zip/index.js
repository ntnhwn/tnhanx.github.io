const { spawn } = require("child_process");
const logger = require("./src/utils/log");
const fs = require("fs");
const { execSync } = require('child_process');
const path = require('path');

const customAsciiArt = `
╔══════════════════════════════════════╗
║            BOT STARTING...           ║
╚══════════════════════════════════════╝
`;

async function checkAndInstallModules() {
    try {
        const files = fs.readdirSync('./modules/commands');
        const errorModules = [];
        const installedPackages = [];

        logger.log('Bắt Đầu Check Modules và Auto Install Package', '[ AUTO-CHECK ]');

        for (const file of files) {
            if (file.endsWith('.js')) {
                try {
                    const modulePath = path.resolve(`./modules/commands/${file}`);
                    delete require.cache[modulePath];

                    const moduleContent = fs.readFileSync(modulePath, 'utf8');
                    const requireMatches = moduleContent.match(/require\(['"`]([^'"`]+)['"`]\)/g);

                    if (requireMatches) {
                        for (const match of requireMatches) {
                            const packageName = match.match(/require\(['"`]([^'"`]+)['"`]\)/)[1];

                            if (!packageName.startsWith('.') && !packageName.startsWith('/') &&
                                !require('module').builtinModules.includes(packageName)) {
                                try {
                                    require.resolve(packageName);
                                } catch {
                                    try {
                                        logger.log(`Đang Cài Đặt Package: ${packageName}`, '[ AUTO-INSTALL ]');
                                        execSync(`npm install ${packageName}`, { stdio: 'pipe', timeout: 30000 });
                                        installedPackages.push(packageName);
                                        logger.log(`✅ Cài Đặt Thành Công: ${packageName}`, '[ AUTO-INSTALL ]');
                                    } catch (installError) {
                                        logger.log(`❌ Lỗi Cài Đặt Package: ${packageName}`, '[ AUTO-INSTALL ]');
                                        errorModules.push({
                                            file,
                                            package: packageName,
                                            error: installError.message
                                        });
                                    }
                                }
                            }
                        }
                    }

                    require(modulePath);
                } catch (error) {
                    errorModules.push({ file, error: error.message, stack: error.stack });
                    logger.log(`❌ Lỗi Module: ${file}`, '[ MODULE-CHECK ]');
                }
            }
        }

        if (installedPackages.length > 0) {
            logger.log(`Đã Tự Động Cài Đặt ${installedPackages.length} Package: ${installedPackages.join(', ')}`, '[ AUTO-INSTALL ]');
        }

        if (errorModules.length === 0) {
            logger.log('✅ Tất Cả Modules Hoạt Động Bình Thường', '[ AUTO-CHECK ]');
        } else {
            logger.log(`❌ Phát Hiện ${errorModules.length} Module Có Lỗi`, '[ AUTO-CHECK ]');
            errorModules.forEach(err => {
                console.log(`\n📁 File: ${err.file}`);
                if (err.package) console.log(`📦 Package: ${err.package}`);
                console.log(`❌ Error: ${err.error}`);
            });
        }

        return { success: errorModules.length === 0, errorModules, installedPackages };
    } catch (error) {
        logger.log('Lỗi Hệ Thống Check Module:', '[ AUTO-CHECK ]');
        console.log(error);
        return { success: false, error: error.message };
    }
}

function startBot(message) {
    if (message) logger.log(`${customAsciiArt}\n${message}`, "[ Bắt Đầu ]");

    const child = spawn("node", ["--trace-warnings", "--async-stack-traces", "main.js"], {
        cwd: __dirname,
        stdio: "inherit",
        shell: true
    });

    child.on("close", (codeExit) => {
        if (codeExit !== 0 || (global.countRestart && global.countRestart < 5)) {
            startBot("Mirai Loading - Tiến Hành Khởi Động Lại");
            global.countRestart += 1;
        }
    });

    child.on("error", function (error) {
        logger.log("Đã xảy ra lỗi: " + JSON.stringify(error), "[ Bắt đầu ]");
    });
}

(async function startb() {
    const checkResult = await checkAndInstallModules();

    if (!checkResult.success && checkResult.errorModules.length > 0) {
        logger.log('⚠️ Một Số Module Có Lỗi, Bot Vẫn Sẽ Khởi Động...', '[ WARNING ]');
    }

    startBot();
})();