
const fs = require("fs");
const { resolve } = require("path");

module.exports.config = {
    name: "anti",
    eventType: ["log:unsubscribe", "log:thread-admins", "log:user-nickname"],
    version: "1.0.0",
    credits: "Merged from ProCoderMew, DongDev, ProCoderCyrus",
    description: "Tích hợp anti out, anti qtv, anti đổi tên bot",
};

module.exports.run = async function ({ event, api, Users, Threads }) {
    const { logMessageType, logMessageData, author, threadID } = event;
    const botID = api.getCurrentUserID();
    
    // Anti Out
    if (logMessageType === "log:unsubscribe") {
        const path = resolve(__dirname, '../commands', 'data', 'antiout.json');
        const { antiout } = require(path);
        const id = logMessageData.leftParticipantFbId;
        const moment = require("moment-timezone");
        var timeNow = moment.tz("Asia/Ho_Chi_Minh").format("HH:mm:ss");
        var fullYear = global.client.getTime("fullYear");
        
        if (author == id && id != botID) {
            const name = await Users.getNameUser(id) || "Người dùng Facebook";
            if (antiout.hasOwnProperty(threadID) && antiout[threadID] == true) {
                try {
                    await api.addUserToGroup(id, threadID);
                    return api.sendMessage(`[ ANTIOUT ]\n────────────────────\n⚠️ Kích hoạt chế độ tự động thêm người dùng khi tự động rời nhóm\n🔰 Trạng thái: Thành công\n👤 Người dùng: ${name}\n⏰ Thời gian: ${timeNow} - ${fullYear}\n────────────────────\n⛔ Nếu bot thêm thất bại có thể người dùng đã chặn bot`, event.threadID, async (err, info) => {
                        await new Promise(resolve => setTimeout(resolve, 60 * 1000));
                        return api.unsendMessage(info.messageID);
                    }, event.messageID);
                } catch (e) {
                    return api.sendMessage(`[ ANTIOUT ]\n────────────────────\n⚠️ Kích hoạt chế độ tự động thêm người dùng khi tự động rời nhóm\n🔰 Trạng thái: Thất bại\n👤 Người dùng: ${name}\n⏰ Thời gian: ${timeNow} - ${fullYear}\n────────────────────\n⛔ Nếu bot thêm thất bại có thể người dùng đã chặn bot`, event.threadID, async (err, info) => {
                        await new Promise(resolve => setTimeout(resolve, 60 * 1000));
                        return api.unsendMessage(info.messageID);
                    }, event.messageID);
                }
            }
        }
    }
    
    // Anti QTV
    if (logMessageType === "log:thread-admins") {
        if (author === botID) return;
        
        const path = resolve(__dirname, '../commands', 'data', 'antiqtv.json');
        
        try {
            let dataA = {};
            if (fs.existsSync(path)) {
                const fileContent = fs.readFileSync(path, 'utf8').trim();
                if (fileContent) {
                    dataA = JSON.parse(fileContent);
                } else {
                    // File rỗng, tạo object mặc định
                    dataA = {};
                    fs.writeFileSync(path, JSON.stringify(dataA, null, 2));
                }
            } else {
                // File không tồn tại, tạo mới
                dataA = {};
                fs.writeFileSync(path, JSON.stringify(dataA, null, 2));
            }
            const foundGroup = Object.keys(dataA).find(groupID => groupID === threadID);
            
            if (dataA && foundGroup !== undefined && dataA[foundGroup] === true) {
                if (logMessageData.ADMIN_EVENT === "add_admin" || logMessageData.ADMIN_EVENT === "remove_admin") {
                    if (logMessageData.TARGET_ID === botID) return;
                    
                    if (logMessageData.ADMIN_EVENT === "remove_admin") {
                        api.changeAdminStatus(threadID, author, false);
                        api.changeAdminStatus(threadID, logMessageData.TARGET_ID, true);
                    } else if (logMessageData.ADMIN_EVENT === "add_admin") {
                        api.changeAdminStatus(threadID, author, false);
                        api.changeAdminStatus(threadID, logMessageData.TARGET_ID, false);
                    }
                    
                    return api.sendMessage("» Kích hoạt chế độ chống cướp box", threadID, event.messageID);
                }
            }
        } catch (error) {
            // Xử lý lỗi
        }
    }
    
    // Anti Bot Name Change
    if (logMessageType === "log:user-nickname") {
        var { participant_id } = logMessageData;
        const threadSetting = (await Threads.getData(String(event.threadID))).data || {};
        const prefix = (threadSetting.hasOwnProperty("PREFIX")) ? threadSetting.PREFIX : global.config.PREFIX;
        var { PREFIX, BOTNAME, ADMINBOT } = global.config;
        var { nickname } = await Threads.getData(threadID, botID);
        var nickname = nickname ? nickname : BOTNAME;
        
        if (participant_id == botID && author != botID && !ADMINBOT.includes(author) && logMessageData.nickname != nickname) {
            api.changeNickname(`『 ${prefix} 』 ⪼ ${global.config.BOTNAME}`, threadID, botID);
            return api.sendMessage(`⚠️ Kích hoạt chế độ cấm đổi tên Bot`, threadID);
        }
    }
    
    return;
};
