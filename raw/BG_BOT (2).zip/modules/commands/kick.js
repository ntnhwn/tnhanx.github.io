module.exports.config = {
    name: "kick",
    version: "1.0.0",
    hasPermssion: 1,
    credits: "Mirai & ProCoderMew",
    description: "Xoá người dùng khỏi nhóm bằng cách tag, reply, kick tất cả hoặc lọc người dùng Facebook",
    commandCategory: "QTV",
    usages: "[tag/reply/all/ndfb]",
    cooldowns: 0
};

module.exports.run = async function ({
    args,
    api,
    event,
    Threads
}) {
    const { threadID, messageID, senderID, participantIDs } = event;
    const botID = api.getCurrentUserID();
    
    try {
        // Kick người dùng Facebook (ndfb)
        if (args[0] === "ndfb") {
            var { userInfo, adminIDs } = await api.getThreadInfo(threadID);    
            var success = 0, fail = 0;
            var arr = [];
            
            for (const e of userInfo) {
                if (e.gender == undefined) {
                    arr.push(e.id);
                }
            }

            adminIDs = adminIDs.map(e => e.id).some(e => e == botID);
            
            if (arr.length == 0) {
                return api.sendMessage("Trong nhóm bạn không tồn tại 'Người dùng Facebook'.", threadID);
            } else {
                api.sendMessage("Nhóm bạn hiện có " + arr.length + " 'Người dùng Facebook'.", threadID, function () {
                    if (!adminIDs) {
                        api.sendMessage("Nhưng bot không phải là quản trị viên nên không thể lọc được.", threadID);
                    } else {
                        api.sendMessage("Bắt đầu lọc..", threadID, async function() {
                            for (const e of arr) {
                                try {
                                    await new Promise(resolve => setTimeout(resolve, 1000));
                                    await api.removeUserFromGroup(parseInt(e), threadID);   
                                    success++;
                                } catch {
                                    fail++;
                                }
                            }
                          
                            api.sendMessage("Đã lọc thành công " + success + " người.", threadID, function() {
                                if (fail != 0) return api.sendMessage("Lọc thất bại " + fail + " người.", threadID);
                            });
                        });
                    }
                });
            }
            return;
        }
        
        // Kick bằng mention
        if (args.join().indexOf('@') !== -1) {
            var mention = Object.keys(event.mentions);
            for (let o in mention) {
                setTimeout(() => {
                    return api.removeUserFromGroup(mention[o], threadID, async function(err) {
                        if (err) return api.sendMessage("Bot cần quyền quản trị viên để kick", threadID, messageID);
                        return;
                    });
                }, 1000);
            }
        } else {
            // Kick bằng reply
            if (event.type == "message_reply") {
                return api.removeUserFromGroup(event.messageReply.senderID, threadID, async function(err) {
                    if (err) return api.sendMessage("Bot cần quyền quản trị viên để kick", threadID, messageID);
                    return;
                });
            } else {
                if (!args[0]) return api.sendMessage(`Vui lòng tag hoặc reply người cần kick hoặc dùng:\n• kick all - kick tất cả\n• kick ndfb - lọc người dùng Facebook`, threadID, messageID);
                else {
                    // Kick all
                    if (args[0] == "all") {
                        const listUserID = participantIDs.filter(ID => ID != botID && ID != senderID);
                        for (let idUser of listUserID) {
                            setTimeout(() => {
                                return api.removeUserFromGroup(idUser, threadID);
                            }, 1000);
                        }
                    }
                }
            }
        }
    } catch {
        return api.sendMessage('Đã xảy ra lỗi khi thực hiện lệnh kick', threadID, messageID);
    }
}