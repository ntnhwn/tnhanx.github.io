module.exports.config = {
  name: 'locmem',
  version: '1.0.0',
  hasPermssion: 1,
  credits: 'MewMew',
  description: 'Lọc cá cảnh trong group',
  commandCategory: 'Tiện ích',
  usages: 'filter [num]',
  cooldowns: 5,
  info: [
    {
      key: 'locmem',
      prompt: 'Số tin nhắn tối thiểu | mặc định = 0',
      type: 'số',
      example: 'filter 1',
    },
    {
      key: 'chú ý',
      prompt: 'Đừng xóa module rankup nếu không muốn bay cả group =))',
      type: '',
      example: '',
    },
  ],
};

module.exports.run = async function ({
  api,
  event,
  args,
  Threads,
  Currencies,
}) {
  const threadID = event.threadID;
  const messageID = event.messageID;

  // Lấy thông tin nhóm
  const threadInfo = await api.getThreadInfo(threadID);

  // Số tin nhắn tối thiểu (mặc định = 0)
  const minExp = !isNaN(args[0]) ? parseInt(args[0]) : 0;

  // Kiểm tra bot có phải admin không
  const botID = api.getCurrentUserID();
  const isBotAdmin = threadInfo.adminIDs.some(admin => admin.id == botID);
  if (!isBotAdmin) {
    return api.sendMessage(
      'Bot cần là quản trị viên để có thể sử dụng lệnh này.',
      threadID,
      messageID
    );
  }

  // Tìm thành viên có số tin nhắn <= minExp
  let listNeedRemove = [];
  for (const user of threadInfo.userInfo) {
    const userData = await Currencies.getData(user.id);
    const exp = userData?.exp ?? 0;
    if (exp <= minExp) {
      listNeedRemove.push(user.id);
    }
  }

  // Loại trừ admin khỏi danh sách
  const adminIDs = threadInfo.adminIDs.map(admin => admin.id);
  listNeedRemove = listNeedRemove.filter(uid => !adminIDs.includes(uid));

  if (listNeedRemove.length === 0) {
    return api.sendMessage(
      `Không có con cá cảnh nào với mức lọc ${minExp} tin nhắn.`,
      threadID,
      messageID
    );
  }

  // Thông báo số lượng thành viên sẽ bị lọc
  api.sendMessage(
    `Tiến hành lọc ${listNeedRemove.length} con cá cảnh có số tin nhắn ≤ ${minExp}...`,
    threadID,
    async () => {
      let success = 0;
      let fail = 0;

      for (const uid of listNeedRemove) {
        try {
          await new Promise(res => setTimeout(res, 1000)); // Delay 1s
          await api.removeUser(parseInt(uid), threadID);
          success++;
        } catch (error) {
          console.log(`Lỗi khi kick ${uid}: ${error}`);
          fail++;
        }
      }

      // Kết quả
      let msg = `Đã lọc thành công ${success} thành viên.`;
      if (fail > 0) msg += `\nLọc thất bại ${fail} thành viên.`;
      api.sendMessage(msg, threadID);
    }
  );
};
