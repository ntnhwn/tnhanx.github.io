
const urls = require("./../../src/datajson/vdgai.json");
const axios = require("axios");
const fs = require("fs");
const path = require("path");

let agent;

class Command {
  constructor(config) {
    this.config = config;
    global.Ljzi = [];
  }

  async onLoad(o) {
    // Ensure cache directory exists
    const cacheDir = path.join(__dirname, "cache");
    if (!fs.existsSync(cacheDir)) {
      fs.mkdirSync(cacheDir, { recursive: true });
    }

    let status = false;
    let hasStarted = false;

    if (!global.client.xôx) {
      global.client.xôx = setInterval(async () => {
        if (status === true || global.Ljzi.length > 10) return;
        status = true;

        if (!hasStarted) {
          console.log(`🔄 Bắt đầu upload.`);
          hasStarted = true;
        }

        try {
          const uploadPromises = [...Array(5)].map(() => 
            upload(urls[Math.floor(Math.random() * urls.length)]).catch(err => {
              console.error("Upload error:", err.message);
              return null;
            })
          );

          const results = await Promise.all(uploadPromises);
          const validResults = results.filter(result => result !== null);

          if (validResults.length > 0) {
            global.Ljzi.push(...validResults);
            console.log(`✅ Hoàn thành upload ${validResults.length} videos mới, tổng cộng: ${global.Ljzi.length}`);
}
        } catch (error) {
          console.error("Upload batch error:", error.message);
        } finally {
          status = false;
        }
      }, 5000);
    }

    async function streamURL(url, type) {
      try {
        const response = await axios({
          method: "GET",
          url,
          responseType: "stream",
          timeout: 30000, // Increased timeout for hosting
          httpsAgent: agent,
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            Accept: "*/*",
          },
        });

        const filePath = path.join(__dirname, "cache", `${Date.now()}.${type}`);
        const writer = fs.createWriteStream(filePath);

        await new Promise((resolve, reject) => {
          response.data.pipe(writer);
          writer.on("finish", resolve);
          writer.on("error", reject);
          
          // Add timeout for write operation
          setTimeout(() => {
            reject(new Error("Write timeout"));
          }, 60000);
        });

        // Clean up file after 60 seconds
        setTimeout(() => {
          try {
            if (fs.existsSync(filePath)) {
              fs.unlinkSync(filePath);
            }
          } catch (err) {
            console.error("File cleanup error:", err.message);
          }
        }, 60 * 1000);

        return fs.createReadStream(filePath);
      } catch (error) {
        console.error("StreamURL error:", error.message);
        throw error;
      }
    }

    async function upload(url) {
      try {
        const stream = await streamURL(url, "mp4");
        const uploadRes = await o.api.httpPostFormData(
          "https://upload.facebook.com/ajax/mercury/upload.php",
          { upload_1024: stream }
        );
        
        const meta = JSON.parse(uploadRes.replace("for (;;);", ""));
        return Object.entries(meta.payload?.metadata?.[0] || {})[0];
      } catch (error) {
        console.error("Upload function error:", error.message);
        throw error;
      }
    }
  }

  async run(o) {
    try {
      const response = await axios.get(
        "https://raw.githubusercontent.com/Sang070801/api/main/thinh1.json",
        { timeout: 10000 }
      );
      const data = response.data;
      const thinhArray = Object.values(data.data);
      const randomThinh = thinhArray[Math.floor(Math.random() * thinhArray.length)];

      const send = (msg) =>
        new Promise((r) =>
          o.api.sendMessage(msg, o.event.threadID, (err, res) => r(res || err), o.event.messageID)
        );

      const t = process.uptime();
      const h = Math.floor(t / 3600);
      const p = Math.floor((t % 3600) / 60);
      const s = Math.floor(t % 60);

      const attachment = global.Ljzi.length > 0 ? global.Ljzi.splice(0, 1) : [];

      await send({
        body: `Thời gian hoạt động\n            ${h}:${p}:${s}`,
        attachment: attachment,
      });
    } catch (error) {
      console.error("Run command error:", error.message);
      
      const send = (msg) =>
        new Promise((r) =>
          o.api.sendMessage(msg, o.event.threadID, (err, res) => r(res || err), o.event.messageID)
        );

      await send("Đã xảy ra lỗi khi thực hiện lệnh.");
    }
  }
}

module.exports = new Command({
  name: "vd",
  version: "0.0.1",
  hasPermssion: 2,
  credits: "DC-Nam, fix 429 Pcoder",
  description: "",
  commandCategory: "Tiện ích",
  usages: "[]",
  cooldowns: 0,
});
