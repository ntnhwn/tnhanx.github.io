module.exports.config = {
  name: "pinmess",
  version: "1.0.0",
  hasPermssion: 1,
  credits: "Dũngkon",
  description: "Ghim hoặc bỏ ghim tin nhắn trong nhóm",
  commandCategory: "QTV",
  usages: "[pinmess <reply>] hoặc [pinmess unpin <reply>]",
  cooldowns: 5
};

module.exports.run = async function({ api, event, args }) {
  try {
    if (!event.messageReply || !event.messageReply.messageID) {
      return api.sendMessage("⚠️ Vui lòng reply tin nhắn bạn muốn ghim hoặc bỏ ghim!", event.threadID, event.messageID);
    }
    const unpin = args[0] && args[0].toLowerCase() === "unpin";
    await api.pinMessage(event.threadID, event.messageReply.messageID, !unpin);
    return api.sendMessage(unpin ? "✅ Đã bỏ ghim tin nhắn!" : "✅ Đã ghim tin nhắn!", event.threadID, event.messageID);
  } catch (e) {
    console.error(e);
    return api.sendMessage("❌ Không thể ghim/bỏ ghim tin nhắn!", event.threadID, event.messageID);
  }
};