
const fs = require('fs');
const path = require('path');
const PackageManager = require('./packageManager');

class ModuleChecker {
    constructor() {
        this.packageManager = new PackageManager();
        this.moduleStatus = new Map();
        this.errorLogs = [];
    }

    // Check syntax của module
    checkModuleSyntax(filePath) {
        try {
            const content = fs.readFileSync(filePath, 'utf8');
            
            // Basic syntax checks
            const checks = {
                hasExports: /module\.exports\s*=|exports\./g.test(content),
                hasConfig: /config\s*:/g.test(content) || /\.config\s*=/g.test(content),
                hasRun: /run\s*:/g.test(content) || /\.run\s*=/g.test(content),
                syntaxValid: true
            };

            // Try to validate JavaScript syntax
            try {
                new Function(content);
            } catch (syntaxError) {
                checks.syntaxValid = false;
                checks.syntaxError = syntaxError.message;
            }

            return checks;
        } catch (error) {
            return { 
                hasExports: false, 
                hasConfig: false, 
                hasRun: false, 
                syntaxValid: false, 
                error: error.message 
            };
        }
    }

    // Test load module
    async testLoadModule(filePath) {
        try {
            // Clear cache
            delete require.cache[path.resolve(filePath)];
            
            // Try to require
            const module = require(filePath);
            
            const checks = {
                loadable: true,
                hasConfig: !!module.config,
                hasRun: !!module.run,
                configValid: this.validateConfig(module.config),
                runValid: typeof module.run === 'function'
            };

            return checks;
        } catch (error) {
            return {
                loadable: false,
                error: error.message,
                stack: error.stack
            };
        }
    }

    // Validate module config
    validateConfig(config) {
        if (!config || typeof config !== 'object') {
            return { valid: false, reason: 'Missing or invalid config object' };
        }

        const required = ['name', 'version', 'hasPermssion', 'credits', 'description'];
        const missing = required.filter(field => !config.hasOwnProperty(field));

        if (missing.length > 0) {
            return { valid: false, reason: `Missing required fields: ${missing.join(', ')}` };
        }

        return { valid: true };
    }

    // Check tất cả modules trong thư mục
    async checkAllModules(modulesDir = './modules/commands') {
        const report = {
            total: 0,
            passed: 0,
            failed: 0,
            modules: [],
            packageReport: null
        };

        try {
            // Auto install packages first
            report.packageReport = await this.packageManager.autoCheckAndInstall(modulesDir);

            const files = fs.readdirSync(modulesDir);
            const jsFiles = files.filter(file => file.endsWith('.js'));
            report.total = jsFiles.length;

            for (const file of jsFiles) {
                const filePath = path.join(modulesDir, file);
                const moduleReport = await this.checkSingleModule(filePath, file);
                
                report.modules.push(moduleReport);
                
                if (moduleReport.status === 'passed') {
                    report.passed++;
                } else {
                    report.failed++;
                }
            }

        } catch (error) {
            this.errorLogs.push({ type: 'system', error: error.message });
        }

        return report;
    }

    // Check module đơn lẻ
    async checkSingleModule(filePath, fileName) {
        const moduleReport = {
            file: fileName,
            path: filePath,
            status: 'unknown',
            checks: {},
            issues: [],
            dependencies: []
        };

        try {
            // 1. Check syntax
            moduleReport.checks.syntax = this.checkModuleSyntax(filePath);
            
            // 2. Check dependencies
            moduleReport.dependencies = this.packageManager.analyzeDependencies(filePath);
            
            // 3. Install missing dependencies
            const missingDeps = moduleReport.dependencies.filter(dep => 
                !this.packageManager.isPackageInstalled(dep)
            );
            
            if (missingDeps.length > 0) {
                try {
                    await this.packageManager.installMultiplePackages(missingDeps);
                } catch (error) {
                    moduleReport.issues.push(`Failed to install dependencies: ${missingDeps.join(', ')}`);
                }
            }

            // 4. Test load module
            moduleReport.checks.loading = await this.testLoadModule(filePath);

            // 5. Determine status
            if (moduleReport.checks.syntax.syntaxValid && 
                moduleReport.checks.loading.loadable &&
                moduleReport.checks.loading.configValid.valid) {
                moduleReport.status = 'passed';
            } else {
                moduleReport.status = 'failed';
                
                // Collect issues
                if (!moduleReport.checks.syntax.syntaxValid) {
                    moduleReport.issues.push(`Syntax error: ${moduleReport.checks.syntax.syntaxError || 'Unknown'}`);
                }
                
                if (!moduleReport.checks.loading.loadable) {
                    moduleReport.issues.push(`Loading error: ${moduleReport.checks.loading.error}`);
                }
                
                if (!moduleReport.checks.loading.configValid?.valid) {
                    moduleReport.issues.push(`Config error: ${moduleReport.checks.loading.configValid?.reason}`);
                }
            }

        } catch (error) {
            moduleReport.status = 'error';
            moduleReport.issues.push(`System error: ${error.message}`);
        }

        return moduleReport;
    }

    // In báo cáo chi tiết
    printDetailedReport(report) {
        console.log('\n' + '='.repeat(60));
        console.log('📊 BÁO CÁO CHECK MODULE CHI TIẾT');
        console.log('='.repeat(60));
        
        console.log(`📁 Tổng số modules: ${report.total}`);
        console.log(`✅ Thành công: ${report.passed}`);
        console.log(`❌ Thất bại: ${report.failed}`);
        
        if (report.packageReport) {
            console.log(`📦 Packages đã cài: ${report.packageReport.installedPackages.length}`);
            console.log(`⚠️ Packages lỗi: ${report.packageReport.failedPackages.length}`);
        }

        console.log('\n📋 CHI TIẾT TỪNG MODULE:');
        console.log('-'.repeat(60));

        report.modules.forEach(module => {
            const statusIcon = module.status === 'passed' ? '✅' : 
                              module.status === 'failed' ? '❌' : '⚠️';
            
            console.log(`\n${statusIcon} ${module.file}`);
            
            if (module.dependencies.length > 0) {
                console.log(`   📦 Dependencies: ${module.dependencies.join(', ')}`);
            }
            
            if (module.issues.length > 0) {
                module.issues.forEach(issue => {
                    console.log(`   ⚠️ ${issue}`);
                });
            }
        });

        console.log('\n' + '='.repeat(60));
    }
}

module.exports = ModuleChecker;
