const fs = require("fs-extra");
const path = require("path");
const axios = require("axios");
const moment = require("moment-timezone");
const { callGemini } = require("../../utils/gemini"); // Giả định bạn có file này
const { v4: uuidv4 } = require("uuid");

// --- CONFIG & SETUP ---
const YT_API_KEY = "AIzaSyAygWrPYHFVzL0zblaZPkRcgIFZkBNAW9g"; // Thay API Key của bạn vào đây
const cacheDir = path.join(__dirname, "../../cache");
fs.ensureDirSync(cacheDir);

// --- DATA FILES ---
const dataPath = path.join(cacheDir, "kem_ai_enabled.json");
if (!fs.existsSync(dataPath)) fs.writeJsonSync(dataPath, {});

const antioutPath = path.join(cacheDir, "antiout.json");
if (!fs.existsSync(antioutPath)) fs.writeJsonSync(antioutPath, {});

let cooldowns = new Map();

module.exports.config = {
  name: "kem",
  version: "4.0.0",
  hasPermssion: 0,
  credits: "ngvanhung fix by mamut",
  description: "Trợ lý AI đa năng với nhiều tiện ích",
  commandCategory: "AI",
  usages: "[on|off|check info ff|infobox|infouser|antiout|đổi biệt danh|...]",
  cooldowns: 3,
};

// --- HELPER FUNCTIONS ---
function convertTimestamp(ts) {
  if (!ts || ts === "Not found") return "Không rõ";
  return moment.unix(parseInt(ts)).tz("Asia/Ho_Chi_Minh").format("DD/MM/YYYY HH:mm:ss");
}

// --- COMMAND HANDLERS ---

/**
 * Xử lý lệnh kiểm tra thông tin Free Fire
 */
async function handleFFInfo(api, event, uid) {
  const { threadID, senderID, messageID } = event;
  if (!uid || isNaN(uid) || uid.length < 6) {
    return api.sendMessage("⚠️ UID Free Fire không hợp lệ!", threadID, messageID);
  }

  const cooldownTime = 30; // 30 giây cooldown
  if (cooldowns.has(senderID)) {
    const lastUsed = cooldowns.get(senderID);
    const diff = (Date.now() - lastUsed) / 1000;
    if (diff < cooldownTime) {
      return api.sendMessage(`⏳ Vui lòng đợi ${Math.ceil(cooldownTime - diff)} giây để dùng lại lệnh này.`, threadID, messageID);
    }
  }
  cooldowns.set(senderID, Date.now());
  api.sendMessage("🔎 Đang tìm thông tin UID, vui lòng chờ...", threadID, messageID);

  try {
    const { data } = await axios.get(`https://glob-info2.vercel.app/info?uid=${uid}`);
    if (!data || !data.basicInfo?.nickname) {
      return api.sendMessage("❌ Không tìm thấy thông tin người chơi. UID có thể không tồn tại.", threadID, messageID);
    }

    const { basicInfo = {}, profileInfo = {}, clanBasicInfo = {} } = data;
    let msg = `🎮 𝗜𝗡𝗙𝗢 𝗙𝗥𝗘𝗘 𝗙𝗜𝗥𝗘 🎮\n`;
    msg += `👤 Tên: ${basicInfo.nickname || "Không rõ"}\n`;
    msg += `🆔 UID: ${uid}\n`;
    msg += `⭐ Level: ${basicInfo.level || "?"} (Exp: ${basicInfo.exp || "?"})\n`;
    msg += `👍 Lượt thích: ${basicInfo.liked || "?"}\n`;
    msg += `📅 Tạo tài khoản: ${convertTimestamp(basicInfo.createAt)}\n`;
    msg += `🔓 Đăng nhập lần cuối: ${convertTimestamp(basicInfo.lastLoginAt)}\n`;
    if (clanBasicInfo?.clanName) {
      msg += `🏰 Bang hội: ${clanBasicInfo.clanName} (Lv.${clanBasicInfo.clanLevel || "?"})\n`;
    }
    msg += `\n📌 Cung cấp bởi Kem AI`;

    const imgRes = await axios.get(`https://genprofile2.vercel.app/generate?uid=${uid}`, { responseType: "arraybuffer" });
    const filePath = path.join(cacheDir, `ff_${uuidv4()}.png`);
    fs.writeFileSync(filePath, imgRes.data);
    api.sendMessage({ body: msg, attachment: fs.createReadStream(filePath) }, threadID, () => fs.unlinkSync(filePath), messageID);
  } catch (err) {
    console.error("❌ Lỗi gọi API Free Fire:", err.message);
    api.sendMessage("❌ Lỗi khi kết nối API Free Fire. Vui lòng thử lại sau.", threadID, messageID);
  }
}

/**
 * Xử lý các lệnh lấy thông tin (infobox, infouser)
 */
async function handleInfoCommands(api, event, args) {
    const { threadID, messageID, senderID, mentions } = event;
    const command = args[0].toLowerCase();

    if (command === "infobox") {
        const threadInfo = await api.getThreadInfo(threadID);
        const { threadName, threadID: tID, participantIDs, adminIDs, approvalMode } = threadInfo;
        const adminCount = adminIDs.length;
        return api.sendMessage(
            `📦 𝗧𝗛𝗢̂𝗡𝗚 𝗧𝗜𝗡 𝗡𝗛𝗢́𝗠\n` +
            `- Tên nhóm: ${threadName}\n` +
            `- ID nhóm: ${tID}\n` +
            `- Số thành viên: ${participantIDs.length}\n` +
            `- Số quản trị viên: ${adminCount}\n` +
            `- Phê duyệt thành viên: ${approvalMode ? "Đang bật" : "Đang tắt"}`,
            threadID, messageID
        );
    }

    if (command === "infouser") {
        const targetID = Object.keys(mentions)[0] || args[1] || senderID;
        const userInfo = await api.getUserInfo(targetID);
        const { name, id, profileUrl, gender, isOnline } = userInfo[targetID];
        return api.sendMessage(
            `👤 𝗧𝗛𝗢̂𝗡𝗚 𝗧𝗜𝗡 𝗡𝗚𝗨̛𝗢̛̀𝗜 𝗗𝗨̀𝗡𝗚\n` +
            `- Tên: ${name}\n` +
            `- ID: ${id}\n` +
            `- Profile: ${profileUrl}\n` +
            `- Giới tính: ${gender === 2 ? "Nam" : "Nữ"}\n` +
            `- Trạng thái: ${isOnline ? "Đang hoạt động" : "Offline"}`,
            threadID, messageID
        );
    }
}

/**
 * Xử lý lệnh mở nhạc
 */
async function handleMusic(api, event, keyword) {
    const { threadID, messageID, senderID } = event;
    if (!keyword) return api.sendMessage("❌ Vui lòng nhập tên bài hát cần tìm.", threadID, messageID);
    api.sendMessage(`🎵 Đang tìm bài hát "${keyword}"...`, threadID, messageID);

    try {
        const res = await axios.get("https://www.googleapis.com/youtube/v3/search", {
            params: { part: "snippet", q: keyword, maxResults: 1, key: YT_API_KEY, type: "video" }
        });
        const item = res.data.items[0];
        if (!item) return api.sendMessage("❌ Không tìm thấy bài hát nào phù hợp.", threadID, messageID);

        const videoUrl = `https://www.youtube.com/watch?v=${item.id.videoId}`;
        api.sendMessage(`✅ Đã tìm thấy: ${item.snippet.title}\n⏳ Đang tải xuống, vui lòng chờ...`, threadID, messageID);

        const audioRes = await axios.get(`https://subhatde.id.vn/youtube/download?url=${encodeURIComponent(videoUrl)}`);
        const audioUrl = audioRes.data.media?.find(m => m.type === "audio")?.url;
        if (!audioUrl) return api.sendMessage("❌ Không thể lấy được link tải âm thanh.", threadID, messageID);

        const filePath = path.join(cacheDir, `kem_music_${senderID}.mp3`);
        const fileStream = await axios.get(audioUrl, { responseType: 'stream' });

        const writer = fs.createWriteStream(filePath);
        fileStream.data.pipe(writer);
        writer.on('finish', () => {
            api.sendMessage({
                body: `🎧 Kem đang phát: ${item.snippet.title}`,
                attachment: fs.createReadStream(filePath)
            }, threadID, () => fs.unlinkSync(filePath), messageID);
        });
        writer.on('error', () => api.sendMessage("❌ Đã xảy ra lỗi khi tải file âm thanh.", threadID, messageID));

    } catch (err) {
        console.error("🎵 Lỗi mở nhạc:", err.message);
        api.sendMessage("❌ Có lỗi xảy ra trong quá trình xử lý nhạc.", threadID, messageID);
    }
}

/**
 * Xử lý chat với AI
 */
async function handleChat(api, event) {
    const { threadID, messageID, senderID, body } = event;
    try {
        api.sendTypingIndicator(threadID, true);
        const userInfo = await api.getUserInfo(senderID);
        const name = userInfo[senderID]?.name || "bạn";

        const prompt = `Bạn là Kem – một trợ lý AI hài hước, thân thiện và thông minh. Hãy trả lời tin nhắn từ người dùng một cách tự nhiên, ngắn gọn và có cảm xúc. Tên người dùng là ${name}. Tin nhắn: "${body}"`;
        const reply = await callGemini(prompt); // Giả định hàm này trả về một chuỗi
        if (reply) {
            api.sendMessage(reply, threadID, messageID);
        }
    } catch (e) {
        console.error("💬 Lỗi chat AI:", e.message);
        api.sendMessage("💦 Kem đang bận, bạn thử lại sau nhé.", threadID, messageID);
    }
}

// --- MAIN EVENT HANDLER ---
module.exports.handleEvent = async function ({ event, api }) {
    const { threadID, messageID, senderID, body, logMessageType, logMessageData } = event;
    if (!body || senderID == api.getCurrentUserID()) {
        // Xử lý sự kiện antiout
        if (logMessageType === 'log:unsubscribe') {
            const antioutDb = fs.readJsonSync(antioutPath, { throws: false }) || {};
            if (antioutDb[threadID] === true) {
                const leftUserID = logMessageData.leftParticipantFbId;
                const userInfo = await api.getUserInfo(leftUserID);
                const name = userInfo[leftUserID]?.name;
                if (name) {
                    api.addUserToGroup(leftUserID, threadID, (err) => {
                        if (err) return console.error("Lỗi antiout:", err);
                        api.sendMessage(`🛡️ Antiout đang bật, đã thêm lại "${name}" vào nhóm.`, threadID);
                    });
                }
            }
        }
        return;
    }

    const db = fs.readJsonSync(dataPath, { throws: false }) || {};
    if (db[threadID] === false) return;

    const lowerBody = body.toLowerCase();
    const botID = api.getCurrentUserID();
    const mentioned = event.mentions && Object.keys(event.mentions).includes(botID);
    const isReply = event.messageReply && event.messageReply.senderID === botID;

    // Lệnh được kích hoạt bằng từ khóa hoặc tag/reply
    const triggerWord = "kem";
    if (lowerBody.startsWith(triggerWord) || mentioned || isReply) {
        const content = body.slice(mentioned ? body.indexOf(' ') + 1 : (lowerBody.startsWith(triggerWord) ? triggerWord.length + 1 : 0)).trim();
        const args = content.toLowerCase().split(/\s+/);

        if (args.includes("check") && args.includes("info") && args.includes("ff")) {
            const uid = content.match(/\d{6,}/)?.[0];
            return handleFFInfo(api, event, uid);
        } else if (args[0] === "infobox" || args[0] === "infouser") {
            return handleInfoCommands(api, event, args);
        } else if (args[0] === "nhạc" || args[0] === "mở" || args[0] === "phát") {
            const keyword = content.split(' ').slice(1).join(' ');
            return handleMusic(api, event, keyword);
        } else {
            // Nếu không phải lệnh cụ thể, thì là chat AI
            return handleChat(api, event);
        }
    }
};

// --- MAIN RUN FUNCTION (for commands) ---
module.exports.run = async function ({ api, event, args, permssion }) {
    const { threadID, messageID, senderID, mentions } = event;
    if (args.length === 0) {
        return api.sendMessage("🧠 Bạn cần dùng lệnh gì? Gõ `kem help` để xem danh sách lệnh.", threadID, messageID);
    }

    const command = args[0].toLowerCase();
    const db = fs.readJsonSync(dataPath, { throws: false }) || {};

    switch (command) {
        case "on":
            db[threadID] = true;
            fs.writeJsonSync(dataPath, db, { spaces: 2 });
            return api.sendMessage("✅ Đã bật Kem AI trong nhóm này.", threadID, messageID);
        case "off":
            db[threadID] = false;
            fs.writeJsonSync(dataPath, db, { spaces: 2 });
            return api.sendMessage("☑️ Đã tắt Kem AI trong nhóm này.", threadID, messageID);
        case "check":
        case "lệch": // từ khóa thay thế
            if (args[1] === "info" && args[2] === "ff") {
                return handleFFInfo(api, event, args[3]);
            }
            break;
        case "infobox":
        case "infouser":
            return handleInfoCommands(api, event, args);
        case "antiout":
            if (permssion < 3) return api.sendMessage("⚠️ Chỉ quản trị viên mới có thể dùng lệnh này.", threadID, messageID);
            const antioutDb = fs.readJsonSync(antioutPath, { throws: false }) || {};
            const status = args[1]?.toLowerCase();
            if (status === "on") {
                antioutDb[threadID] = true;
                fs.writeJsonSync(antioutPath, antioutDb, { spaces: 2 });
                return api.sendMessage("🛡️ Đã bật tính năng Antiout.", threadID, messageID);
            } else if (status === "off") {
                antioutDb[threadID] = false;
                fs.writeJsonSync(antioutPath, antioutDb, { spaces: 2 });
                return api.sendMessage("☑️ Đã tắt tính năng Antiout.", threadID, messageID);
            } else {
                return api.sendMessage("👉 Dùng: `kem antiout [on|off]`", threadID, messageID);
            }
        case "đổi":
            const subCommand = args[1];
            const value = args.slice(2).join(" ");
            if (subCommand === "biệt" && args[2] === "danh") {
                const newNickname = args.slice(3).join(" ");
                const targetID = Object.keys(mentions)[0] || senderID;
                api.changeNickname(newNickname, threadID, targetID);
                return api.sendMessage(`✅ Đã đổi biệt danh thành công.`, threadID, messageID);
            }
            if (subCommand === "icon") {
                api.changeThreadEmoji(value, threadID);
                return api.sendMessage(`✅ Đã đổi icon nhóm thành ${value}.`, threadID, messageID);
            }
            if (subCommand === "tên" && args[2] === "nhóm") {
                api.setTitle(args.slice(3).join(" "), threadID);
                return api.sendMessage(`✅ Đã đổi tên nhóm thành công.`, threadID, messageID);
            }
            break;
        default:
            return api.sendMessage("⚠️ Lệnh không hợp lệ. Gõ `kem help` để xem hướng dẫn.", threadID, messageID);
    }
};
