const axios = require("axios");
const moment = require('moment-timezone');
const fs = require('fs');
const path = require('path');
const ytsr = require('youtube-sr');

module.exports.config = {
  name: "spt",
  version: "2.6.0",
  hasPermssion: 0,
  credits: "Tiến", // mod nvh
  description: "Tìm kiếm nhạc đa nền tảng với tính năng nâng cao + Download MP3",
  commandCategory: "Tiện ích",
  usages: "[từ khóa] | -artist [tên nghệ sĩ] | -album [tên album] | -genre [thể loại] | -year [năm] | -lyrics [bài hát] | -download [bài hát]",
  images: [],
  cooldowns: 3,
};

const API_ENDPOINTS = {
  spotify: {
    token: 'https://accounts.spotify.com/api/token',
    search: 'https://api.spotify.com/v1/search',
    track: 'https://api.spotify.com/v1/tracks',
    artist: 'https://api.spotify.com/v1/artists',
    album: 'https://api.spotify.com/v1/albums',
    recommendations: 'https://api.spotify.com/v1/recommendations'
  },
  lastfm: 'https://ws.audioscrobbler.com/2.0/',
  genius: 'https://api.genius.com',
  musixmatch: 'https://api.musixmatch.com/ws/1.1',
  musicbrainz: 'https://musicbrainz.org/ws/2',
  lyrics: 'https://api.lyrics.ovh/v1',
  itunes: 'https://itunes.apple.com/search',
  niio_download: 'https://niio-team.onrender.com/downr',
  spotify_download: 'https://cdn-spotify.zm.io.vn/download'
};

const API_KEYS = {
  spotify: {
    clientId: 'b9d2557a2dd64105a37f413fa5ffcda4',
    clientSecret: '41bdf804974e4e70bfa0515bb3097fbb'
  },
  lastfm: '8b2b23434b950d63b0de86e2bb2b97a7',
  genius: 'demo_key'
};

function formatDuration(ms) {
  const seconds = Math.floor((ms / 1000) % 60);
  const minutes = Math.floor((ms / (1000 * 60)) % 60);
  const hours = Math.floor(ms / (1000 * 60 * 60));
  
  if (hours > 0) {
    return `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }
  return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

function calculateSimilarity(str1, str2) {
  const normalize = (str) => str.toLowerCase()
    .replace(/[^\w\s]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  
  const s1 = normalize(str1);
  const s2 = normalize(str2);
  
  if (s1 === s2) return 1;
  
  const words1 = s1.split(' ');
  const words2 = s2.split(' ');
  
  let commonWords = 0;
  words1.forEach(word => {
    if (words2.includes(word) && word.length > 2) {
      commonWords++;
    }
  });
  
  return commonWords / Math.max(words1.length, words2.length);
}

async function verifyAudioStream(stream, trackInfo, requestId, source) {
  try {
    console.log(`🔍 [${requestId}] Xác thực stream từ ${source} cho: ${trackInfo.artist} - ${trackInfo.title}`);
    
    // Kiểm tra xem stream có hợp lệ không
    if (!stream || typeof stream.pipe !== 'function') {
      throw new Error(`Stream từ ${source} không hợp lệ`);
    }
    
    // Kiểm tra content-type nếu có
    if (stream.headers && stream.headers['content-type']) {
      const contentType = stream.headers['content-type'];
      console.log(`📄 [${requestId}] Content-Type từ ${source}: ${contentType}`);
      
      if (!contentType.includes('audio') && !contentType.includes('video') && !contentType.includes('octet-stream')) {
        console.log(`⚠️ [${requestId}] Cảnh báo: Content-Type không phải audio từ ${source}`);
      }
    }
    
    // Kiểm tra content-length nếu có
    if (stream.headers && stream.headers['content-length']) {
      const contentLength = parseInt(stream.headers['content-length']);
      console.log(`📏 [${requestId}] Content-Length từ ${source}: ${contentLength} bytes`);
      
      // Nếu file quá nhỏ (< 100KB), có thể là lỗi
      if (contentLength < 100000) {
        console.log(`⚠️ [${requestId}] Cảnh báo: File từ ${source} có vẻ quá nhỏ (${contentLength} bytes)`);
      }
    }
    
    console.log(`✅ [${requestId}] Stream từ ${source} đã được xác thực cho: ${trackInfo.artist} - ${trackInfo.title}`);
    return stream;
  } catch (error) {
    console.error(`❌ [${requestId}] Lỗi xác thực stream từ ${source}:`, error.message);
    throw error;
  }
}

async function downloadFromSpotifyAPI(trackId, trackInfo, requestId) {
  try {
    console.log(`🎵 [${requestId}] Thử tải từ Spotify API: ${trackInfo.artist} - ${trackInfo.title}`);
    const spotifyUrl = `${API_ENDPOINTS.spotify_download}/${trackId}/GBAHT1901121?name=${encodeURIComponent(trackInfo.title)}&artist=${encodeURIComponent(trackInfo.artist)}`;
    
    console.log(`🔗 [${requestId}] Spotify URL: ${spotifyUrl}`);
    
    const response = await axios.get(spotifyUrl, {
      responseType: 'stream',
      timeout: 60000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    
    if (response.status === 200) {
      console.log(`✅ [${requestId}] Spotify API response thành công cho: ${trackInfo.artist} - ${trackInfo.title}`);
      
      // Xác thực stream trước khi trả về
      const verifiedStream = await verifyAudioStream(response.data, trackInfo, requestId, 'Spotify API');
      return verifiedStream;
    }
    
    throw new Error('Spotify download không khả dụng');
  } catch (error) {
    console.error(`❌ [${requestId}] Spotify API thất bại cho ${trackInfo.artist} - ${trackInfo.title}:`, error.message);
    throw error;
  }
}

async function downloadWithNiio(url, trackInfo, requestId) {
  try {
    console.log(`🔄 [${requestId}] Thử Niio API cho: ${trackInfo.artist} - ${trackInfo.title}`);
    console.log(`📺 [${requestId}] YouTube URL: ${url}`);
    
    const response = await axios.get(`${API_ENDPOINTS.niio_download}?url=${encodeURIComponent(url)}`, {
      timeout: 30000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });

    console.log(`📋 [${requestId}] Niio API response:`, JSON.stringify(response.data, null, 2));

    if (response.data && response.data.success && response.data.download_url) {
      const downloadUrl = response.data.download_url;
      console.log(`🔗 [${requestId}] Niio download URL: ${downloadUrl}`);
      console.log(`✅ [${requestId}] Niio API trả về link thành công cho: ${trackInfo.artist} - ${trackInfo.title}`);
      
      const audioResponse = await axios.get(downloadUrl, {
        responseType: 'stream',
        timeout: 60000
      });
      
      // Xác thực stream trước khi trả về
      const verifiedStream = await verifyAudioStream(audioResponse.data, trackInfo, requestId, 'Niio API');
      return verifiedStream;
    }
    
    throw new Error('Không thể lấy link download từ Niio API');
  } catch (error) {
    console.error(`❌ [${requestId}] Niio API thất bại cho ${trackInfo.artist} - ${trackInfo.title}:`, error.message);
    throw error;
  }
}

async function downloadWithCobalt(url, trackInfo, requestId) {
  try {
    console.log(`🔄 [${requestId}] Thử Cobalt API cho: ${trackInfo.artist} - ${trackInfo.title}`);
    console.log(`📺 [${requestId}] YouTube URL: ${url}`);
    
    // Thử với format mp3 trước
    let cobaltResponse = await axios.post('https://api.cobalt.tools/api/json', {
      url: url,
      vFormat: 'mp3',
      vQuality: '128'
    }, {
      timeout: 20000,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });

    console.log(`📋 [${requestId}] Cobalt API response (MP3):`, JSON.stringify(cobaltResponse.data, null, 2));

    if (cobaltResponse.data && cobaltResponse.data.status === 'success') {
      const audioUrl = cobaltResponse.data.url;
      console.log(`🔗 [${requestId}] Cobalt MP3 URL: ${audioUrl}`);
      console.log(`✅ [${requestId}] Cobalt API (MP3) trả về link thành công cho: ${trackInfo.artist} - ${trackInfo.title}`);
      
      const audioResponse = await axios.get(audioUrl, {
        responseType: 'stream',
        timeout: 60000
      });
      
      // Xác thực stream trước khi trả về
      const verifiedStream = await verifyAudioStream(audioResponse.data, trackInfo, requestId, 'Cobalt API (MP3)');
      return verifiedStream;
    }

    // Nếu mp3 không có, thử với m4a
    cobaltResponse = await axios.post('https://api.cobalt.tools/api/json', {
      url: url,
      vFormat: 'm4a',
      vQuality: '128'
    }, {
      timeout: 20000,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });

    console.log(`📋 [${requestId}] Cobalt API response (M4A):`, JSON.stringify(cobaltResponse.data, null, 2));

    if (cobaltResponse.data && cobaltResponse.data.status === 'success') {
      const audioUrl = cobaltResponse.data.url;
      console.log(`🔗 [${requestId}] Cobalt M4A URL: ${audioUrl}`);
      console.log(`✅ [${requestId}] Cobalt API (M4A) trả về link thành công cho: ${trackInfo.artist} - ${trackInfo.title}`);
      
      const audioResponse = await axios.get(audioUrl, {
        responseType: 'stream',
        timeout: 60000
      });
      
      // Xác thực stream trước khi trả về
      const verifiedStream = await verifyAudioStream(audioResponse.data, trackInfo, requestId, 'Cobalt API (M4A)');
      return verifiedStream;
    }

    throw new Error('Cobalt API không trả về kết quả');
  } catch (error) {
    console.error(`❌ [${requestId}] Cobalt API thất bại cho ${trackInfo.artist} - ${trackInfo.title}:`, error.message);
    throw error;
  }
}

function parseSearchQuery(query) {
  const filters = {
    artist: null,
    album: null,
    genre: null,
    year: null,
    lyrics: false,
    download: false,
    general: query
  };

  const patterns = {
    artist: /-artist\s+([^-]+)/i,
    album: /-album\s+([^-]+)/i,
    genre: /-genre\s+([^-]+)/i,
    year: /-year\s+(\d{4})/i,
    lyrics: /-lyrics/i,
    download: /-download/i
  };

  Object.keys(patterns).forEach(key => {
    const match = query.match(patterns[key]);
    if (match) {
      if (key === 'lyrics' || key === 'download') {
        filters[key] = true;
      } else {
        filters[key] = match[1].trim();
      }
      query = query.replace(match[0], '').trim();
    }
  });

  filters.general = query || filters.artist || filters.album || '';
  return filters;
}

async function getSpotifyToken() {
  try {
    const response = await axios.post(API_ENDPOINTS.spotify.token, 
      'grant_type=client_credentials', {
      headers: {
        'Authorization': 'Basic ' + Buffer.from(
          API_KEYS.spotify.clientId + ':' + API_KEYS.spotify.clientSecret
        ).toString('base64'),
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      timeout: 10000
    });
    return response.data.access_token;
  } catch (error) {
    throw new Error('Không thể kết nối Spotify API');
  }
}

async function searchSpotify(query, filters, limit = 10) {
  try {
    const token = await getSpotifyToken();
    let searchQuery = query;
    
    if (filters.artist) searchQuery += ` artist:${filters.artist}`;
    if (filters.album) searchQuery += ` album:${filters.album}`;
    if (filters.genre) searchQuery += ` genre:${filters.genre}`;
    if (filters.year) searchQuery += ` year:${filters.year}`;

    const response = await axios.get(API_ENDPOINTS.spotify.search, {
      headers: { Authorization: `Bearer ${token}` },
      params: {
        q: searchQuery,
        type: 'track,artist,album',
        limit: limit,
        market: 'VN'
      },
      timeout: 15000
    });

    return response.data;
  } catch (error) {
    console.error('Spotify search error:', error.message);
    return null;
  }
}

async function searchYouTubeForSpecificTrack(trackInfo, requestId) {
  try {
    console.log(`🔍 [${requestId}] Tìm kiếm YouTube cho bài hát cụ thể: ${trackInfo.artist} - ${trackInfo.title}`);
    
    const queries = [
      `"${trackInfo.artist}" "${trackInfo.title}" official audio`,
      `"${trackInfo.artist}" "${trackInfo.title}" official`,
      `${trackInfo.artist} ${trackInfo.title} official audio`,
      `${trackInfo.artist} ${trackInfo.title} audio`,
      `"${trackInfo.artist}" "${trackInfo.title}"`,
      `${trackInfo.artist} ${trackInfo.title}`
    ];

    let allResults = [];
    
    for (const query of queries) {
      try {
        console.log(`🔍 [${requestId}] Thử query: "${query}"`);
        const searchResults = await ytsr(query, { 
          limit: 5,
          safeSearch: false,
          gl: 'US',
          hl: 'en'
        });
        
        const videos = searchResults.items.filter(item => 
          item.type === 'video' && 
          item.duration && 
          item.duration !== 'LIVE' &&
          !item.isUpcoming &&
          item.url &&
          item.id
        );
        
        allResults = allResults.concat(videos);
        
        if (allResults.length >= 15) break;
      } catch (error) {
        console.log(`❌ [${requestId}] Query thất bại: ${query}`, error.message);
        continue;
      }
    }

    const uniqueResults = [];
    const seenIds = new Set();
    
    allResults.forEach(video => {
      if (!seenIds.has(video.id)) {
        seenIds.add(video.id);
        
        const titleSimilarity = calculateSimilarity(video.title, `${trackInfo.artist} ${trackInfo.title}`);
        const authorSimilarity = calculateSimilarity(video.author?.name || '', trackInfo.artist);
        
        let bonusScore = 0;
        const titleLower = video.title.toLowerCase();
        const trackTitleLower = trackInfo.title.toLowerCase();
        const trackArtistLower = trackInfo.artist.toLowerCase();
        
        if (titleLower.includes(trackTitleLower)) bonusScore += 0.4;
        if (titleLower.includes(trackArtistLower)) bonusScore += 0.3;
        
        if (titleLower.includes('official')) bonusScore += 0.3;
        if (titleLower.includes('audio')) bonusScore += 0.2;
        if (titleLower.includes('lyrics')) bonusScore += 0.1;
        if (titleLower.includes('music video')) bonusScore += 0.1;
        
        if (titleLower.includes('cover')) bonusScore -= 0.3;
        if (titleLower.includes('remix')) bonusScore -= 0.3;
        if (titleLower.includes('live')) bonusScore -= 0.2;
        if (titleLower.includes('karaoke')) bonusScore -= 0.4;
        if (titleLower.includes('instrumental')) bonusScore -= 0.2;
        
        const totalScore = (titleSimilarity * 0.5) + (authorSimilarity * 0.3) + bonusScore;
        
        uniqueResults.push({
          ...video,
          similarity: totalScore,
          titleSimilarity,
          authorSimilarity,
          bonusScore
        });
      }
    });

    uniqueResults.sort((a, b) => b.similarity - a.similarity);
    
    const topResults = uniqueResults.slice(0, 5);
    
    console.log(`📋 [${requestId}] Top ${topResults.length} video cho "${trackInfo.artist} - ${trackInfo.title}":`);
    topResults.forEach((video, index) => {
      console.log(`[${requestId}] ${index + 1}. "${video.title}" by ${video.author?.name || 'Unknown'} (Score: ${video.similarity.toFixed(3)})`);
    });
    
    return topResults.map(video => ({
      id: video.id,
      title: video.title,
      url: video.url,
      duration: video.duration,
      thumbnail: video.bestThumbnail?.url || video.thumbnails?.[0]?.url,
      author: video.author?.name || video.ownerText?.runs?.[0]?.text,
      similarity: video.similarity,
      titleSimilarity: video.titleSimilarity,
      authorSimilarity: video.authorSimilarity
    }));
  } catch (error) {
    console.error(`❌ [${requestId}] YouTube search thất bại cho ${trackInfo.artist} - ${trackInfo.title}:`, error.message);
    return await searchYouTubeAlternative(`${trackInfo.artist} ${trackInfo.title}`);
  }
}

async function searchYouTube(query) {
  try {
    const searchResults = await ytsr(query, { 
      limit: 10,
      safeSearch: false,
      gl: 'US',
      hl: 'en'
    });
    
    const videos = searchResults.items.filter(item => 
      item.type === 'video' && 
      item.duration && 
      item.duration !== 'LIVE' &&
      !item.isUpcoming &&
      item.url &&
      item.id
    );
    
    return videos.slice(0, 5).map(video => ({
      id: video.id,
      title: video.title,
      url: video.url,
      duration: video.duration,
      thumbnail: video.bestThumbnail?.url || video.thumbnails?.[0]?.url,
      author: video.author?.name || video.ownerText?.runs?.[0]?.text
    }));
  } catch (error) {
    console.error('YouTube search error:', error.message);
    return await searchYouTubeAlternative(query);
  }
}

async function searchYouTubeAlternative(query) {
  try {
    const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
    const response = await axios.get(searchUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      },
      timeout: 15000
    });

    const videoMatches = response.data.match(/\/watch\?v=([a-zA-Z0-9_-]{11})/g);
    if (!videoMatches) return [];

    const videoIds = [...new Set(videoMatches.map(match => match.replace('/watch?v=', '')))].slice(0, 5);
    
    return videoIds.map(id => ({
      id: id,
      title: query,
      url: `https://www.youtube.com/watch?v=${id}`,
      duration: null,
      thumbnail: `https://img.youtube.com/vi/${id}/maxresdefault.jpg`,
      author: 'Unknown'
    }));
  } catch (error) {
    console.error('Alternative search failed:', error.message);
    return [];
  }
}

async function downloadMP3(trackInfo) {
  // Tạo unique request ID để track từng request riêng biệt
  const requestId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  
  try {
    let audioStream = null;
    let downloadMethod = '';

    console.log(`\n🎯 [${requestId}] === BẮT ĐẦU TẢI: ${trackInfo.artist} - ${trackInfo.title} ===`);
    console.log(`📋 [${requestId}] Track ID: ${trackInfo.id || 'N/A'}`);

    // Phương pháp 1: Thử tải từ Spotify API trước (nếu có trackId)
    if (trackInfo.id) {
      try {
        audioStream = await downloadFromSpotifyAPI(trackInfo.id, trackInfo, requestId);
        downloadMethod = 'Spotify API';
        console.log(`✅ [${requestId}] === THÀNH CÔNG TỪ SPOTIFY API: ${trackInfo.artist} - ${trackInfo.title} ===\n`);
        return audioStream;
      } catch (spotifyError) {
        console.log(`❌ [${requestId}] Spotify API thất bại cho ${trackInfo.artist} - ${trackInfo.title}`);
      }
    }

    // Phương pháp 2: Tìm trên YouTube với độ chính xác cao cho bài hát cụ thể
    console.log(`🔄 [${requestId}] Chuyển sang tìm kiếm YouTube cho: ${trackInfo.artist} - ${trackInfo.title}`);
    const youtubeResults = await searchYouTubeForSpecificTrack(trackInfo, requestId);
    
    if (youtubeResults.length === 0) {
      throw new Error(`Không tìm thấy "${trackInfo.artist} - ${trackInfo.title}" trên YouTube`);
    }

    let attempts = 0;
    const maxAttempts = Math.min(youtubeResults.length, 3);

    for (const video of youtubeResults.slice(0, maxAttempts)) {
      try {
        attempts++;
        const videoUrl = video.url;
        console.log(`\n🔄 [${requestId}] === ATTEMPT ${attempts} cho ${trackInfo.artist} - ${trackInfo.title} ===`);
        console.log(`📺 [${requestId}] Video: "${video.title}" by ${video.author || 'Unknown'}`);
        console.log(`🎯 [${requestId}] Score: ${video.similarity.toFixed(3)} | URL: ${videoUrl}`);
        
        // Thử API Niio trước
        try {
          audioStream = await downloadWithNiio(videoUrl, trackInfo, requestId);
          if (audioStream) {
            downloadMethod = 'Niio API';
            console.log(`✅ [${requestId}] === THÀNH CÔNG TỪ NIIO: ${trackInfo.artist} - ${trackInfo.title} ===\n`);
            return audioStream;
          }
        } catch (niioError) {
          console.log(`❌ [${requestId}] Niio thất bại cho attempt ${attempts}`);
        }
        
        // Fallback về Cobalt API
        try {
          audioStream = await downloadWithCobalt(videoUrl, trackInfo, requestId);
          if (audioStream) {
            downloadMethod = 'Cobalt API';
            console.log(`✅ [${requestId}] === THÀNH CÔNG TỪ COBALT: ${trackInfo.artist} - ${trackInfo.title} ===\n`);
            return audioStream;
          }
        } catch (cobaltError) {
          console.log(`❌ [${requestId}] Cobalt thất bại cho attempt ${attempts}`);
        }
        
      } catch (videoError) {
        console.log(`❌ [${requestId}] Attempt ${attempts} hoàn toàn thất bại cho ${trackInfo.artist} - ${trackInfo.title}`);
        if (attempts >= maxAttempts) {
          throw videoError;
        }
        continue;
      }
    }

    throw new Error(`Tất cả phương pháp tải đều thất bại cho "${trackInfo.artist} - ${trackInfo.title}"`);
  } catch (error) {
    console.error(`❌ [${requestId}] === LỖI CUỐI CÙNG cho ${trackInfo.artist} - ${trackInfo.title}: ${error.message} ===\n`);
    
    let errorMessage = `Không thể tải "${trackInfo.artist} - ${trackInfo.title}". `;
    if (error.message.includes('YouTube')) {
      errorMessage += 'Không tìm thấy trên YouTube. ';
    } else if (error.message.includes('Niio')) {
      errorMessage += 'Lỗi API Niio. ';
    } else if (error.message.includes('Cobalt')) {
      errorMessage += 'Lỗi API Cobalt. ';
    } else if (error.message.includes('Spotify')) {
      errorMessage += 'Lỗi Spotify API. ';
    }
    errorMessage += 'Vui lòng thử bài khác hoặc thử lại sau.';
    
    throw new Error(errorMessage);
  }
}

async function getLastFmInfo(artist, track) {
  try {
    const response = await axios.get(API_ENDPOINTS.lastfm, {
      params: {
        method: 'track.getInfo',
        api_key: API_KEYS.lastfm,
        artist: artist,
        track: track,
        format: 'json'
      },
      timeout: 10000
    });
    
    return response.data.track || null;
  } catch (error) {
    return null;
  }
}

async function getTrackLyrics(artist, title) {
  const lyricAPIs = [
    `${API_ENDPOINTS.lyrics}/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`,
    `https://lrclib.net/api/get?artist_name=${encodeURIComponent(artist)}&track_name=${encodeURIComponent(title)}`,
    `https://api.textyl.co/api/lyrics?q=${encodeURIComponent(artist + ' ' + title)}`
  ];

  for (const api of lyricAPIs) {
    try {
      const response = await axios.get(api, { timeout: 10000 });
      if (response.data && (response.data.lyrics || response.data.plainLyrics || response.data.syncedLyrics)) {
        return {
          lyrics: response.data.lyrics || response.data.plainLyrics || response.data.syncedLyrics,
          source: api.includes('lyrics.ovh') ? 'Lyrics.ovh' : 
                  api.includes('lrclib') ? 'LRCLIB' : 'Textyl'
        };
      }
    } catch (error) {
      continue;
    }
  }
  return null;
}

async function getArtistInfo(artistName) {
  try {
    const response = await axios.get(API_ENDPOINTS.lastfm, {
      params: {
        method: 'artist.getInfo',
        api_key: API_KEYS.lastfm,
        artist: artistName,
        format: 'json'
      },
      timeout: 10000
    });
    
    return response.data.artist || null;
  } catch (error) {
    return null;
  }
}

async function getTopTracks(artistName) {
  try {
    const response = await axios.get(API_ENDPOINTS.lastfm, {
      params: {
        method: 'artist.getTopTracks',
        api_key: API_KEYS.lastfm,
        artist: artistName,
        limit: 5,
        format: 'json'
      },
      timeout: 10000
    });
    
    return response.data.toptracks?.track || [];
  } catch (error) {
    return [];
  }
}

async function getSimilarArtists(artistName) {
  try {
    const response = await axios.get(API_ENDPOINTS.lastfm, {
      params: {
        method: 'artist.getSimilar',
        api_key: API_KEYS.lastfm,
        artist: artistName,
        limit: 5,
        format: 'json'
      },
      timeout: 10000
    });
    
    return response.data.similarartists?.artist || [];
  } catch (error) {
    return [];
  }
}

async function getTrackTags(artist, track) {
  try {
    const response = await axios.get(API_ENDPOINTS.lastfm, {
      params: {
        method: 'track.getTags',
        api_key: API_KEYS.lastfm,
        artist: artist,
        track: track,
        format: 'json'
      },
      timeout: 10000
    });
    
    return response.data.tags?.tag || [];
  } catch (error) {
    return [];
  }
}

async function downloadImage(url) {
  try {
    if (!url) return null;
    const response = await axios.get(url, { 
      responseType: "stream",
      timeout: 15000
    });
    return response.data;
  } catch (error) {
    return null;
  }
}

async function enhanceTrackData(track) {
  const enhanced = { ...track };
  
  try {
    const lastfmInfo = await getLastFmInfo(track.artist, track.title);
    if (lastfmInfo) {
      enhanced.playcount = lastfmInfo.playcount;
      enhanced.listeners = lastfmInfo.listeners;
      enhanced.summary = lastfmInfo.wiki?.summary?.replace(/<[^>]*>/g, '').substring(0, 200);
    }

    const tags = await getTrackTags(track.artist, track.title);
    if (tags.length > 0) {
      enhanced.genres = tags.map(tag => tag.name).slice(0, 3);
    }

    return enhanced;
  } catch (error) {
    return enhanced;
  }
}

module.exports.run = async function ({ api, event, args }) {
  try {
    const rawQuery = args.join(" ");
    
    if (!rawQuery) {
      const helpText = `🎵 [ HƯỚNG DẪN SỬ DỤNG ]\n────────────────────\n📝 Tìm kiếm cơ bản:\n• spt [từ khóa]\n\n🎯 Tìm kiếm nâng cao:\n• spt -artist Sơn Tùng MTP\n• spt -album Vietnam Top Hits\n• spt -genre pop\n• spt -year 2023\n• spt -lyrics Lạc Trôi\n• spt -download Shape of You\n\n🔧 Kết hợp nhiều bộ lọc:\n• spt -artist "Ed Sheeran" -year 2023\n• spt Shape of You -lyrics\n• spt -artist "Taylor Swift" -download\n\n💡 Các tính năng:\n• Thông tin chi tiết nghệ sĩ & bài hát\n• Lời bài hát từ nhiều nguồn\n• Download MP3/M4A chất lượng cao\n• Top tracks & similar artists\n• Genres & tags\n• Play count & listeners\n• Preview audio (nếu có)\n\n📥 Lưu ý: Chức năng download cần kết nối ổn định\n🔧 Hỗ trợ: Spotify API, YouTube (Verified Download), Niio, Cobalt\n🎯 FIXED: Xác thực stream và kiểm tra tính toàn vẹn file tải về`;
      
      return api.sendMessage(helpText, event.threadID, event.messageID);
    }

    const filters = parseSearchQuery(rawQuery);
    
    if (filters.lyrics && filters.general) {
      const searchingMsg = await api.sendMessage("🔍 Đang tìm lời bài hát...", event.threadID);
      
      const lyricsData = await getTrackLyrics(filters.artist || '', filters.general);
      api.unsendMessage(searchingMsg.messageID);
      
      if (lyricsData) {
        const lyricsPreview = lyricsData.lyrics.length > 1000 ? 
          lyricsData.lyrics.substring(0, 1000) + "..." : lyricsData.lyrics;
        
        return api.sendMessage({
          body: `🎵 [ LỜI BÀI HÁT ]\n────────────────────\n📝 Bài hát: ${filters.general}\n👤 Nghệ sĩ: ${filters.artist || 'Không xác định'}\n📊 Nguồn: ${lyricsData.source}\n\n${lyricsPreview}\n\n⏰ ${moment.tz("Asia/Ho_Chi_Minh").format("DD/MM/YYYY || HH:mm:ss")}`
        }, event.threadID);
      } else {
        return api.sendMessage(`❌ Không tìm thấy lời bài hát cho: "${filters.general}"`, event.threadID);
      }
    }

    if (filters.download && filters.general) {
      const searchingMsg = await api.sendMessage("🔍 Đang tìm kiếm để tải xuống...", event.threadID);
      
      const spotifyData = await searchSpotify(filters.general, filters, 5);
      api.unsendMessage(searchingMsg.messageID);

      if (!spotifyData || !spotifyData.tracks || spotifyData.tracks.items.length === 0) {
        return api.sendMessage(`❎ Không tìm thấy bài hát để tải: "${filters.general}"`, event.threadID);
      }

      const tracks = spotifyData.tracks.items.map(item => ({
        id: item.id,
        title: item.name,
        artist: item.artists[0].name,
        allArtists: item.artists.map(a => a.name).join(', '),
        duration: item.duration_ms,
        thumbnail: item.album.images[0]?.url || null,
        spotifyUrl: item.external_urls.spotify,
        album: item.album.name,
        popularity: item.popularity
      }));

      const trackList = tracks.map((track, index) => {
        const duration = formatDuration(track.duration);
        return `\n${index + 1}. 🎵 ${track.title}\n👤 ${track.allArtists}\n💿 ${track.album}\n⏳ ${duration} | ⭐ ${track.popularity}%`;
      });

      const message = {
        body: `🎵 [ CHỌN BÀI DOWNLOAD ]\n────────────────────\n🔍 Tìm kiếm: "${filters.general}"\n📊 Tìm thấy: ${tracks.length} kết quả\n${trackList.join("\n─────────────────")}\n\n💡 Reply số để tải MP3/M4A\n⚠️ Quá trình tải có thể mất 1-2 phút\n🎯 FIXED: Verified download với xác thực stream\n🔧 Hỗ trợ: Spotify API → Verified YouTube Search → Niio → Cobalt`
      };

      return api.sendMessage(message, event.threadID, (error, info) => {
        if (error) return;
        
        global.client.handleReply.push({
          type: "download_choose",
          name: module.exports.config.name,
          author: event.senderID,
          messageID: info.messageID,
          tracks: tracks,
          filters: filters
        });
      });
    }

    const searchingMsg = await api.sendMessage("🔍 Đang tìm kiếm đa nền tảng...", event.threadID);
    
    const spotifyData = await searchSpotify(filters.general, filters, 8);
    api.unsendMessage(searchingMsg.messageID);

    if (!spotifyData || !spotifyData.tracks || spotifyData.tracks.items.length === 0) {
      return api.sendMessage(`❎ Không tìm thấy kết quả cho: "${filters.general}"`, event.threadID, event.messageID);
    }

    const tracks = [];
    for (const item of spotifyData.tracks.items) {
      const trackData = {
        id: item.id,
        title: item.name,
        artist: item.artists[0].name,
        allArtists: item.artists.map(a => a.name).join(', '),
        duration: item.duration_ms,
        thumbnail: item.album.images[0]?.url || null,
        spotifyUrl: item.external_urls.spotify,
        previewUrl: item.preview_url,
        album: item.album.name,
        releaseDate: item.album.release_date,
        popularity: item.popularity,
        explicit: item.explicit,
        trackNumber: item.track_number,
        albumType: item.album.album_type,
        totalTracks: item.album.total_tracks
      };
      
      const enhanced = await enhanceTrackData(trackData);
      tracks.push(enhanced);
    }

    const images = [];
    for (const track of tracks.slice(0, 4)) {
      if (track.thumbnail) {
        const imageStream = await downloadImage(track.thumbnail);
        if (imageStream) images.push(imageStream);
      }
    }

    const trackList = tracks.map((track, index) => {
      const duration = formatDuration(track.duration);
      const explicit = track.explicit ? "🔞 " : "";
      const playcount = track.playcount ? `\n▶️ Lượt phát: ${Number(track.playcount).toLocaleString()}` : "";
      const listeners = track.listeners ? `\n👥 Người nghe: ${Number(track.listeners).toLocaleString()}` : "";
      const genres = track.genres ? `\n🎼 Thể loại: ${track.genres.join(", ")}` : "";
      
      return `\n${index + 1}. ${explicit}🎵 ${track.title}\n👤 ${track.allArtists}\n💿 ${track.album} (${track.albumType})\n⏳ ${duration} | Track ${track.trackNumber}/${track.totalTracks}\n⭐ Spotify: ${track.popularity}%${playcount}${listeners}${genres}`;
    });

    const filterInfo = [];
    if (filters.artist) filterInfo.push(`👤 Artist: ${filters.artist}`);
    if (filters.album) filterInfo.push(`💿 Album: ${filters.album}`);
    if (filters.genre) filterInfo.push(`🎼 Genre: ${filters.genre}`);
    if (filters.year) filterInfo.push(`📅 Year: ${filters.year}`);

    const message = {
      body: `🎵 [ ĐA NỀN TẢNG - KẾT QUẢ ]\n────────────────────\n🔍 Tìm kiếm: "${filters.general}"\n${filterInfo.length > 0 ? filterInfo.join("\n") + "\n" : ""}📊 Tìm thấy: ${tracks.length} kết quả\n${trackList.join("\n─────────────────")}\n\n💡 Reply số để xem chi tiết đầy đủ\n📥 Reply "d[số]" để tải MP3/M4A (vd: d1)\n🎯 Sử dụng: spt -help để xem hướng dẫn\n🆕 FIXED: Verified download với xác thực stream`,
      attachment: images
    };

    api.sendMessage(message, event.threadID, (error, info) => {
      if (error) return;
      
      global.client.handleReply.push({
        type: "choose",
        name: module.exports.config.name,
        author: event.senderID,
        messageID: info.messageID,
        tracks: tracks,
        filters: filters
      });
    });

  } catch (error) {
    console.error("Main error:", error);
    return api.sendMessage(`❌ Đã xảy ra lỗi: ${error.message}`, event.threadID, event.messageID);
  }
};

module.exports.handleReply = async function ({ api, event, handleReply }) {
  try {
    const { type, tracks, filters } = handleReply;
    const userChoice = event.body.trim();

    if (type === "choose") {
      if (userChoice.toLowerCase().startsWith("d")) {
        const trackIndex = parseInt(userChoice.substring(1)) - 1;
        
        if (trackIndex >= 0 && trackIndex < tracks.length) {
          const selectedTrack = tracks[trackIndex];
          
          const downloadingMsg = await api.sendMessage(`🔄 Đang tải "${selectedTrack.title}" - ${selectedTrack.allArtists}...\n⏳ Vui lòng chờ 1-2 phút\n🎯 Verified download với xác thực stream\n🔧 Thử: Spotify API → Verified YouTube → Niio → Cobalt`, event.threadID);
          
          try {
            // Tạo stream mới hoàn toàn cho request này
            const audioStream = await downloadMP3(selectedTrack);
            api.unsendMessage(downloadingMsg.messageID);
            
            const fileName = `${selectedTrack.artist} - ${selectedTrack.title}.mp3`
              .replace(/[^\w\s-]/g, "")
              .replace(/\s+/g, " ")
              .trim();

            return api.sendMessage({
              body: `✅ [ DOWNLOAD THÀNH CÔNG ]\n────────────────────\n🎵 ${selectedTrack.title}\n👤 ${selectedTrack.allArtists}\n💿 ${selectedTrack.album}\n⏳ ${formatDuration(selectedTrack.duration)}\n⭐ Popularity: ${selectedTrack.popularity}%\n\n🎧 Chất lượng: High Quality Audio\n🎯 Tìm kiếm: Verified download với xác thực stream\n📥 Tải xuống hoàn tất!`,
            attachment: audioStream
          }, event.threadID);
            
          } catch (downloadError) {
            api.unsendMessage(downloadingMsg.messageID);
            return api.sendMessage(`❌ ${downloadError.message}`, event.threadID);
          }
        } else {
          return api.sendMessage("❌ Số thứ tự không hợp lệ!", event.threadID);
        }
      } else {
        const trackIndex = parseInt(userChoice) - 1;
        
        if (trackIndex >= 0 && trackIndex < tracks.length) {
          const selectedTrack = tracks[trackIndex];
          
          const loadingMsg = await api.sendMessage("🔍 Đang tải thông tin chi tiết...", event.threadID);
          
          const artistInfo = await getArtistInfo(selectedTrack.artist);
          const topTracks = await getTopTracks(selectedTrack.artist);
          const similarArtists = await getSimilarArtists(selectedTrack.artist);
          
          api.unsendMessage(loadingMsg.messageID);
          
          const duration = formatDuration(selectedTrack.duration);
          const releaseYear = new Date(selectedTrack.releaseDate).getFullYear();
          const explicit = selectedTrack.explicit ? "🔞 Explicit" : "✅ Clean";
          
          let detailMessage = `🎵 [ CHI TIẾT BÀI HÁT ]\n────────────────────\n📝 Tên: ${selectedTrack.title}\n👤 Nghệ sĩ: ${selectedTrack.allArtists}\n💿 Album: ${selectedTrack.album} (${selectedTrack.albumType})\n📅 Năm phát hành: ${releaseYear}\n⏳ Thời lượng: ${duration}\n🎯 Track: ${selectedTrack.trackNumber}/${selectedTrack.totalTracks}\n⭐ Spotify Popularity: ${selectedTrack.popularity}%\n🔒 ${explicit}`;
          
          if (selectedTrack.playcount) {
            detailMessage += `\n▶️ Lượt phát: ${Number(selectedTrack.playcount).toLocaleString()}`;
          }
          
          if (selectedTrack.listeners) {
            detailMessage += `\n👥 Người nghe: ${Number(selectedTrack.listeners).toLocaleString()}`;
          }
          
          if (selectedTrack.genres && selectedTrack.genres.length > 0) {
            detailMessage += `\n🎼 Thể loại: ${selectedTrack.genres.join(", ")}`;
          }
          
          if (selectedTrack.summary) {
            detailMessage += `\n\n📖 Mô tả: ${selectedTrack.summary}`;
          }
          
          if (artistInfo && artistInfo.stats) {
            detailMessage += `\n\n👤 [ THÔNG TIN NGHỆ SĨ ]\n────────────────────\n▶️ Lượt phát: ${Number(artistInfo.stats.playcount).toLocaleString()}\n👥 Người nghe: ${Number(artistInfo.stats.listeners).toLocaleString()}`;
          }
          
          if (topTracks.length > 0) {
            detailMessage += `\n\n🔥 [ TOP TRACKS ]\n────────────────────`;
            topTracks.slice(0, 3).forEach((track, index) => {
              detailMessage += `\n${index + 1}. ${track.name}`;
              if (track.playcount) {
                detailMessage += ` (${Number(track.playcount).toLocaleString()} plays)`;
              }
            });
          }
          
          if (similarArtists.length > 0) {
            detailMessage += `\n\n🎭 [ NGHỆ SĨ TƯƠNG TỰ ]\n────────────────────\n${similarArtists.slice(0, 3).map(artist => artist.name).join(", ")}`;
          }
          
          detailMessage += `\n\n🔗 Spotify: ${selectedTrack.spotifyUrl}`;
          detailMessage += `\n📥 Reply "download" để tải MP3/M4A (Verified download)`;
          detailMessage += `\n🎤 Reply "lyrics" để xem lời bài hát`;
          
          const images = [];
          if (selectedTrack.thumbnail) {
            const imageStream = await downloadImage(selectedTrack.thumbnail);
            if (imageStream) images.push(imageStream);
          }
          
          return api.sendMessage({
            body: detailMessage,
            attachment: images
          }, event.threadID, (error, info) => {
            if (error) return;
            
            global.client.handleReply.push({
              type: "detail_action",
              name: module.exports.config.name,
              author: event.senderID,
              messageID: info.messageID,
              track: selectedTrack,
              filters: filters
            });
          });
        } else {
          return api.sendMessage("❌ Số thứ tự không hợp lệ!", event.threadID);
        }
      }
    }

    if (type === "download_choose") {
      const trackIndex = parseInt(userChoice) - 1;
      
      if (trackIndex >= 0 && trackIndex < tracks.length) {
        const selectedTrack = tracks[trackIndex];
        
        const downloadingMsg = await api.sendMessage(`🔄 Đang tải "${selectedTrack.title}" - ${selectedTrack.allArtists}...\n⏳ Vui lòng chờ 1-2 phút\n🎯 Verified download với xác thực stream\n🔧 Thử: Spotify API → Verified YouTube → Niio → Cobalt`, event.threadID);
        
        try {
          // Tạo stream mới hoàn toàn cho request này
          const audioStream = await downloadMP3(selectedTrack);
          api.unsendMessage(downloadingMsg.messageID);
          
          const fileName = `${selectedTrack.artist} - ${selectedTrack.title}.mp3`
            .replace(/[^\w\s-]/g, "")
            .replace(/\s+/g, " ")
            .trim();

          return api.sendMessage({
            body: `✅ [ DOWNLOAD THÀNH CÔNG ]\n────────────────────\n🎵 ${selectedTrack.title}\n👤 ${selectedTrack.allArtists}\n💿 ${selectedTrack.album}\n⏳ ${formatDuration(selectedTrack.duration)}\n⭐ Popularity: ${selectedTrack.popularity}%\n\n🎧 Chất lượng: High Quality Audio\n🎯 Tìm kiếm: Verified download với xác thực stream\n📥 Tải xuống hoàn tất!`,
            attachment: audioStream
          }, event.threadID);
          
        } catch (downloadError) {
          api.unsendMessage(downloadingMsg.messageID);
          return api.sendMessage(`❌ ${downloadError.message}`, event.threadID);
        }
      } else {
        return api.sendMessage("❌ Số thứ tự không hợp lệ!", event.threadID);
      }
    }

    if (type === "detail_action") {
      const { track } = handleReply;
      
      if (userChoice.toLowerCase() === "download") {
        const downloadingMsg = await api.sendMessage(`🔄 Đang tải "${track.title}" - ${track.allArtists}...\n⏳ Vui lòng chờ 1-2 phút\n🎯 Verified download với xác thực stream\n🔧 Thử: Spotify API → Verified YouTube → Niio → Cobalt`, event.threadID);
        
        try {
          // Tạo stream mới hoàn toàn cho request này
          const audioStream = await downloadMP3(track);
          api.unsendMessage(downloadingMsg.messageID);
          
          return api.sendMessage({
            body: `✅ [ DOWNLOAD THÀNH CÔNG ]\n────────────────────\n🎵 ${track.title}\n👤 ${track.allArtists}\n💿 ${track.album}\n⏳ ${formatDuration(track.duration)}\n⭐ Popularity: ${track.popularity}%\n\n🎧 Chất lượng: High Quality Audio\n🎯 Tìm kiếm: Verified download với xác thực stream\n📥 Tải xuống hoàn tất!`,
            attachment: audioStream
          }, event.threadID);
          
        } catch (downloadError) {
          api.unsendMessage(downloadingMsg.messageID);
          return api.sendMessage(`❌ ${downloadError.message}`, event.threadID);
        }
      }
      
      if (userChoice.toLowerCase() === "lyrics") {
        const searchingMsg = await api.sendMessage("🔍 Đang tìm lời bài hát...", event.threadID);
        
        const lyricsData = await getTrackLyrics(track.artist, track.title);
        api.unsendMessage(searchingMsg.messageID);
        
        if (lyricsData) {
          const lyricsPreview = lyricsData.lyrics.length > 1500 ? 
            lyricsData.lyrics.substring(0, 1500) + "..." : lyricsData.lyrics;
          
          return api.sendMessage({
            body: `🎵 [ LỜI BÀI HÁT ]\n────────────────────\n📝 ${track.title}\n👤 ${track.allArtists}\n📊 Nguồn: ${lyricsData.source}\n\n${lyricsPreview}\n\n⏰ ${moment.tz("Asia/Ho_Chi_Minh").format("DD/MM/YYYY || HH:mm:ss")}`
          }, event.threadID);
        } else {
          return api.sendMessage(`❌ Không tìm thấy lời bài hát cho: "${track.title}"`, event.threadID);
        }
      }
    }

  } catch (error) {
    console.error("HandleReply error:", error);
    return api.sendMessage(`❌ Đã xảy ra lỗi: ${error.message}`, event.threadID);
  }
};