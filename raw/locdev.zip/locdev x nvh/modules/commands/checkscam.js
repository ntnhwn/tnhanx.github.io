const scamChecker = require('../../utils/scamChecker');

module.exports.config = {
  name: "checkscam",
  version: "2.0.0",
  hasPermssion: 0,
  credits: "Quất",
  description: "Kiểm tra số điện thoại hoặc link Facebook có bị báo cáo lừa đảo không",
  commandCategory: "Tiện ích",
  usages: "[số điện thoại/link Facebook]",
  cooldowns: 10,
  dependencies: {
    "puppeteer": ""
  }
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, senderID, body } = event;
  const botID = api.getCurrentUserID();
  
  if (senderID === botID) return;
  
  try {
    // Lấy query từ args hoặc từ body nếu không có args
    let query = args.join(' ').trim();
    
    if (!query) {
      return api.sendMessage(
        `╭─────────────────╮
  📌 HƯỚNG DẪN SỬ DỤNG
╰─────────────────╯
${global.config.PREFIX}checkscam [số điện thoại/link Facebook]

╭─────────────────╮
  📝 VÍ DỤ
╰─────────────────╯
${global.config.PREFIX}checkscam 0123456789
${global.config.PREFIX}checkscam https://facebook.com/username`,
        threadID, messageID
      );
    }

    // Kiểm tra xem có phải số điện thoại hoặc link Facebook không
    const phoneRegex = /0\d{9}/g;
    const facebookRegex = /(?:https?:\/\/)?(?:www\.)?(?:facebook\.com|fb\.com|m\.facebook\.com)\/[^\s]+/gi;
    
    if (!phoneRegex.test(query) && !facebookRegex.test(query)) {
      return api.sendMessage(
        "⚠️ Vui lòng nhập số điện thoại (10 chữ số bắt đầu bằng 0) hoặc link Facebook hợp lệ!",
        threadID, messageID
      );
    }

    await api.sendMessage("⏳ Đang kiểm tra thông tin...", threadID, messageID);
    
    const result = await scamChecker.checkScam(query);
    
    if (result) {
      await api.sendMessage(
        `📊 **KẾT QUẢ CHECK SCAM CHO "${query}"**:\n\n${result}`,
        threadID, messageID
      );
    } else {
      await api.sendMessage(
        `❌ Không thể kiểm tra thông tin cho "${query}"`,
        threadID, messageID
      );
    }
    
  } catch (error) {
    console.error('Lỗi trong checkscam command:', error);
    await api.sendMessage(
      `❌ Đã xảy ra lỗi: ${error.message}`,
      threadID, messageID
    );
  }
};