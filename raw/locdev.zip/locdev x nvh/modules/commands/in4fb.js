const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const moment = require("moment-timezone");

module.exports.config = {
  name: "in4",
  version: "1.1.0",
  hasPermission: 0,
  credits: "VanHung x Vincent", // thay credits làm chó
  description: "Lấy thông tin Facebook người dùng",
  commandCategory: "Thông tin",
  usages: "[uid/link hoặc reply]",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, messageReply, senderID } = event;
  const input = args.join(" ");
  const timeNow = moment.tz("Asia/Ho_Chi_Minh").format("HH:mm:ss DD/MM/YYYY");

  const token = "EAAAAUaZA8jlABPOoPv7Jvt8bTAQ5RxDrMyEu5vW6Q343E39VGGhqrup7QNaOaq89ZCCpOwSpUGGSdWYaPkEzFeOZAcs6MWca2LH9sxEmj5hyLUatCIqQMMyWFjCZBNmC7MPs6B9gfvKERUaRymnv6VHr7yJ6IAHhThCuqlm3yMO8lvEoeW3tjQwmtp7j39cjhwZDZD"; // Thay token Graph API v17 trở lên
  const cookie = "vpd=v1%3B827x423x1.7000000476837158; fbl_st=101716785%3BT%3A29240393; xs=50%3AuxAdC1dZpolX_A%3A2%3A1754423608%3A-1%3A-1; c_user=100000895922054; fr=0pPPvjnWu4HYSG088.AWdHKocKvqRRO1Z5HEsHlRwycfqUDaBEBCNAWZNnd5SiRwoGoTI.Bokcsk..AAA.0.0.BokmRe.AWclMBAdmSoIDmVqMQLRb_4i-Mw; pas=100000895922054%3ApMPHVEFORf; locale=vi_VN; m_pixel_ratio=1.7000000476837158; wl_cbv=v2%3Bclient_version%3A2886%3Btimestamp%3A1754423611%3BCRCM%3A-1732216877; ps_l=1; ps_n=1; sb=JMuRaHgzkDoOk7PHdc6XTJAM; wd=424x942; datr=JMuRaH_DsEOj3rO0QcLqTelC;" //cookie acc 

  let uid;
  if (messageReply) {
    uid = messageReply.senderID;
  } else if (input.includes("facebook.com")) {
    try {
      const res = await axios.get(`https://graph.facebook.com/v17.0/?id=${encodeURIComponent(input)}&access_token=${token}`);
      uid = res.data.id;
    } catch {
      return api.sendMessage("❌ Không lấy được UID từ link!", threadID, messageID);
    }
  } else if (/^\d{9,20}$/.test(input)) {
    uid = input;
  } else if (!input) {
    uid = senderID;
  } else {
    return api.sendMessage("⚠️ Nhập UID hoặc link hợp lệ.", threadID, messageID);
  }

  try {
    const headers = {
      "Cookie": cookie,
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    };

    const [info, follower] = await Promise.all([
      axios.get(`https://graph.facebook.com/${uid}?fields=id,name,link,gender,birthday,location,hometown,relationship_status,work,education,locale,verified,created_time&access_token=${token}`),
      axios.get(`https://www.facebook.com/${uid}`, { headers })
    ]);

    const profile = info.data;
    const html = follower.data;

    const name = profile.name || "Lỗi";
    const username = profile.link?.split("/").pop() || "Không rõ";
    const link = profile.link || `https://facebook.com/${uid}`;
    const gender = profile.gender === "male" ? "Nam" : profile.gender === "female" ? "Nữ" : undefined;
    const birthday = profile.birthday;
    const hometown = profile.hometown?.name;
    const location = profile.location?.name;
    const relationship = profile.relationship_status;
    const education = profile.education?.[0]?.school?.name;
    const work = profile.work?.[0]?.employer?.name;
    const locale = profile.locale;
    const verified = profile.verified ? "Đã xác minh" : "Chưa xác minh";
    const created = profile.created_time
      ? moment(profile.created_time).tz("Asia/Ho_Chi_Minh").format("HH:mm:ss DD/MM/YYYY")
      : undefined;

    const matchFollower = html.match(/"followers":(\d+)/);
    const followers = matchFollower ? matchFollower[1] : undefined;

    const avatar = `https://graph.facebook.com/${uid}/picture?width=720&height=720`;

    let result = "━━━━━━━━━━━━━━━━━━\n";
    result += `🧠 Tên: ${name}\n`;
    result += `🆔 UID: ${uid}\n`;
    result += `🌐 Link: ${link}\n`;
    if (username !== "Không rõ") result += `👤 Username: ${username}\n`;
    if (created) result += `📅 Ngày tạo: ${created}\n`;
    if (verified) result += `✔️ Xác minh: ${verified}\n`;
    if (gender) result += `📌 Giới tính: ${gender}\n`;
    if (birthday) result += `🎂 Ngày sinh: ${birthday}\n`;
    if (hometown) result += `🏠 Quê quán: ${hometown}\n`;
    if (location) result += `📍 Nơi ở: ${location}\n`;
    if (relationship) result += `💘 Mối quan hệ: ${relationship}\n`;
    if (education) result += `🧑‍🎓 Học vấn: ${education}\n`;
    if (work) result += `💼 Công việc: ${work}\n`;
    if (followers) result += `👥 Follower: ${followers}\n`;
    if (locale) result += `🌍 Ngôn ngữ: ${locale}\n`;
    result += `🔄 Cập nhật: ${timeNow}\n`;
    result += "━━━━━━━━━━━━━━━━━━\n";
    result += `⏰ Time: ${timeNow}\n`;
    result += `✍️ Admin: VanHung x Vincent\n`;
    result += "━━━━━━━━━━━━━━━━━━";

    const imgPath = path.join(__dirname, "cache", `${uid}.jpg`);
    const img = (await axios.get(avatar, { responseType: "arraybuffer" })).data;
    fs.writeFileSync(imgPath, img);

    return api.sendMessage(
      { body: result, attachment: fs.createReadStream(imgPath) },
      threadID,
      () => fs.unlinkSync(imgPath),
      messageID
    );
  } catch (e) {
    console.log(e.response?.data || e.message);
    return api.sendMessage("❌ Không lấy được thông tin người dùng!", threadID, messageID);
  }
};