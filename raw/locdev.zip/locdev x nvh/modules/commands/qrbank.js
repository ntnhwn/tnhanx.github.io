const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports.config = {
 name: "vietqr",
 version: "1.1.0",
 hasPermssion: 0,
 credits: "nvh",
 description: "Tạo mã QR chuyển khoản ngân hàng bằng tên ngân hàng",
 commandCategory: "tiện ích",
 usages: "[tên ngân hàng] [stk] [tên chủ tk] [số tiền] [nội dung]",
 cooldowns: 5
};

// Danh sách mapping tên gọi -> mã ngân hàng
const bankMap = {
 vietinbank: '970415',
 vietcombank: '970436', vcb: '970436',
 ocb: '970448',
 bidv: '970418',
 agribank: '970405',
 mbbank: '970422', mb: '970422',
 techcombank: '970407', techcom: '970407',
 acb: '970416',
 vpbank: '970432',
 tpbank: '970423',
 sacombank: '970403',
 hdbank: '970437',
 vietcapitalbank: '970454',
 scb: '970429',
 vib: '970441',
 shb: '970443',
 eximbank: '970431',
 msb: '970426',
 cake: '546034',
 ubank: '546035',
 timo: '963388',
 viettelmoney: '971005',
 vnptmoney: '971011'
};

const bankName = {
 '970415': 'VietinBank',
 '970436': 'Vietcombank',
 '970448': 'OCB',
 '970418': 'BIDV',
 '970405': 'Agribank',
 '970422': 'MB Bank',
 '970407': 'Techcombank',
 '970416': 'ACB',
 '970432': 'VPBank',
 '970423': 'TPBank',
 '970403': 'Sacombank',
 '970437': 'HDBank',
 '970454': 'VietCapitalBank',
 '970429': 'SCB',
 '970441': 'VIB',
 '970443': 'SHB',
 '970431': 'Eximbank',
 '970426': 'MSB',
 '546034': 'CAKE by VPBank',
 '546035': 'Ubank by VPBank',
 '963388': 'TIMO',
 '971005': 'ViettelMoney',
 '971011': 'VNPTMoney'
};

module.exports.run = async function ({ api, event, args }) {
 if (args.length < 5) {
 const list = Object.entries(bankMap)
 .filter(([k, v], i, arr) => arr.findIndex(([kk]) => kk === k) === i)
 .map(([alias, code]) => `• ${alias} => ${code}`)
 .join('\n');

 return api.sendMessage(
 "⚠️ Vui lòng nhập đúng định dạng:\n" +
 "vietqr [tên ngân hàng] [stk] [tên chủ tk] [số tiền] [nội dung]\n\n" +
 "Ví dụ:\nvietqr mbbank 123456789 Nguyễn Văn A 50000 napgame\n\n" +
 "📌 Danh sách ngân hàng hỗ trợ:\n" + list,
 event.threadID, event.messageID
 );
 }

 const [bankAlias, accountNumber, ...rest] = args;
 const amount = rest[rest.length - 2];
 const additionalInfo = rest[rest.length - 1];
 const accountName = rest.slice(0, -2).join(' ');

 const bankCode = bankMap[bankAlias.toLowerCase()];
 if (!bankCode) {
 return api.sendMessage(`❌ Không tìm thấy ngân hàng: ${bankAlias}\nBạn có thể thử lại bằng tên khác như: mbbank, vcb, timo, cake,...`, event.threadID, event.messageID);
 }

 try {
 const url = `https://api.vietqr.io/image/${bankCode}-${accountNumber}-wgEtlNH.jpg?accountName=${encodeURIComponent(accountName)}&amount=${encodeURIComponent(amount)}&addInfo=${encodeURIComponent(additionalInfo)}`;
 const response = await axios.get(url, { responseType: 'arraybuffer' });

 const filePath = path.join(__dirname, 'cache', `vietqr_${event.senderID}.jpg`);
 fs.writeFileSync(filePath, Buffer.from(response.data, 'binary'));

 const message = `✅ Mã QR chuyển khoản đã được tạo:\n\n🏦 Ngân hàng: ${bankName[bankCode]} (${bankAlias})\n🔢 STK: ${accountNumber}\n👤 Tên: ${accountName}\n💰 Số tiền: ${amount} VND\n📝 Nội dung: ${additionalInfo}`;

 return api.sendMessage({
 body: message,
 attachment: fs.createReadStream(filePath)
 }, event.threadID, () => fs.unlinkSync(filePath), event.messageID);

 } catch (error) {
 console.error(error);
 return api.sendMessage("❌ Lỗi tạo mã QR, vui lòng kiểm tra lại thông tin.", event.threadID, event.messageID);
 }
};