const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports.config = {
  name: 'tikinfo',
  version: '1.1.0',
  hasPermssion: 0,
  credits: 'vh',
  description: 'Lấy thông tin TikTok user',
  commandCategory: 'media',
  usages: 'tikinfo <username>',
  cooldowns: 3
};

const UA = 'Mozilla/5.0';
const CACHE_DIR = path.join(__dirname, 'cache');
fs.mkdirSync(CACHE_DIR, { recursive: true });

function parseUniqueId(input = '') {
  input = input.trim();
  const m = input.match(/tiktok\.com\/@([^/?\s]+)/i);
  if (m) return m[1];
  return input.replace(/^@/, '');
}

async function fetchUser(username) {
  const url = `https://www.tikwm.com/api/user/info?unique_id=${encodeURIComponent(username)}`;
  const { data } = await axios.get(url, { headers: { 'user-agent': UA }, timeout: 20000 });

  if (!data) throw new Error('Không nhận được dữ liệu từ TikWM');
  if (data.code !== 0) throw new Error(data.msg || 'TikWM API failed');
  if (!data.data?.user) throw new Error('Không tìm thấy thông tin user');

  const u = data.data.user;
  const s = data.data.stats || {};
  return {
    id: u.id,
    uniqueId: u.uniqueId,
    nickname: u.nickname,
    avatar: u.avatarLarger || u.avatarMedium || u.avatarThumb,
    signature: u.signature,
    verified: u.verified,
    follower: s.followerCount,
    following: s.followingCount,
    hearts: s.heartCount,
    videos: s.videoCount
  };
}

async function download(url, filePath) {
  const res = await axios.get(url, {
    responseType: 'stream',
    headers: { 'user-agent': UA },
    timeout: 60000
  });
  await new Promise((resolve, reject) => {
    const w = fs.createWriteStream(filePath);
    res.data.pipe(w);
    w.on('finish', resolve);
    w.on('error', reject);
  });
}

function num(n) {
  if (n == null) return '0';
  const s = Number(n);
  if (s >= 1e9) return (s / 1e9).toFixed(2).replace(/\.00$/, '') + 'B';
  if (s >= 1e6) return (s / 1e6).toFixed(2).replace(/\.00$/, '') + 'M';
  if (s >= 1e3) return (s / 1e3).toFixed(2).replace(/\.00$/, '') + 'K';
  return s.toString();
}

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  const input = (args.join(' ') || '').trim();

  if (!input) {
    return api.sendMessage('Dùng: tikinfo <username>', threadID, messageID);
  }

  const username = parseUniqueId(input);

  try {
    const u = await fetchUser(username);
    const avatarPath = path.join(CACHE_DIR, `tikinfo_${u.uniqueId}_${Date.now()}.jpg`);
    let hasAvatar = false;
    try {
      await download(u.avatar, avatarPath);
      hasAvatar = true;
    } catch (e) {
      console.log('Không tải được avatar:', e.message);
    }

    const msg =
      `👤 ${u.nickname} (@${u.uniqueId})\n` +
      `🆔 ID: ${u.id}\n` +
      `👥 Followers: ${num(u.follower)} | Following: ${num(u.following)}\n` +
      `❤️ Hearts: ${num(u.hearts)} | 🎬 Videos: ${u.videos}\n` +
      (u.verified ? '✅ Verified\n' : '') +
      (u.signature ? `📝 Bio: ${u.signature}` : '');

    api.sendMessage(
      hasAvatar
        ? { body: msg, attachment: fs.createReadStream(avatarPath) }
        : { body: msg },
      threadID,
      () => {
        if (hasAvatar) fs.unlink(avatarPath, () => {});
      },
      messageID
    );
  } catch (e) {
    api.sendMessage(`Lỗi: ${e.message || e}`, threadID, messageID);
  }
};