const puppeteer = require('puppeteer');

class ScamChecker {
  constructor() {
    this.browser = null;
  }

  async initBrowser() {
    if (this.browser) return this.browser;
    
    this.browser = await puppeteer.launch({
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-web-security',
        '--disable-features=VizDisplayCompositor',
        '--disable-background-timer-throttling',
        '--disable-backgrounding-occluded-windows',
        '--disable-renderer-backgrounding',
        '--disable-features=TranslateUI',
        '--disable-ipc-flooding-protection'
      ],
      protocolTimeout: 60000
    });
    
    return this.browser;
  }

  async closeBrowser() {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
    }
  }

  async checkScam(query) {
    const browser = await this.initBrowser();
    
    try {
      const page = await browser.newPage();
      await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
      await page.setRequestInterception(true);
      
      page.on('request', (req) => {
        const reqUrl = req.url();
        if (reqUrl.includes('telegram') || reqUrl.includes('discord') || 
            reqUrl.includes('google-analytics') || reqUrl.includes('googletagmanager') || 
            reqUrl.includes('doubleclick')) {
          req.abort();
        } else {
          req.continue();
        }
      });

      const searchUrl = `https://checkscam.vn/?qh_ss=${encodeURIComponent(query)}`;
      await page.goto(searchUrl, { waitUntil: 'networkidle0', timeout: 60000 });
      await new Promise(resolve => setTimeout(resolve, 3000));

      let additionalInfo = '';
      try {
        const pageText = await page.evaluate(() => document.body.textContent);
        const escQuery = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const warningMatch = pageText.match(new RegExp(`Có (\\d+) cảnh báo liên quan đến[^\\d]*"${escQuery}"`, 'i'));
        const scamMatch = pageText.match(new RegExp(`Có (\\d+) vụ lừa đảo liên quan đến[^\\d]*"${escQuery}"`, 'i'));

        if (warningMatch || scamMatch) {
          const match = warningMatch || scamMatch;
          const warningCount = parseInt(match[1]);
          const warningType = warningMatch ? 'cảnh báo' : 'vụ lừa đảo';

          if (warningCount === 0) {
            additionalInfo = `✅ KẾT QUẢ CHO "${query}":\n• Chưa xác định - Không có ${warningType} nào liên quan đến "${query}"\n\n`;
          } else {
            additionalInfo = `⚠️ CẢNH BÁO CHO "${query}":\n• Có ${warningCount} ${warningType} liên quan đến "${query}"\n\n`;
            const warningDetails = await page.evaluate(() => {
              const warnings = [];
              const warningElements = document.querySelectorAll('.ct');
              warningElements.forEach((element) => {
                const nameElement = element.querySelector('.ct1 a');
                const dateElement = element.querySelector('.ct2 span:first-child');
                const viewElement = element.querySelector('.ct2 span:last-child');
                if (nameElement && dateElement && viewElement) {
                  const name = nameElement.textContent.trim();
                  const date = dateElement.textContent.trim();
                  const views = viewElement.textContent.trim();
                  warnings.push({ name, date, views, link: nameElement.href });
                }
              });
              return warnings;
            });

            if (warningDetails.length > 0) {
              additionalInfo += `📋 CHI TIẾT CÁC CẢNH BÁO:\n`;
              const actualWarnings = warningDetails.filter(warning =>
                !warning.name.match(/^\d+$/) &&
                !warning.name.includes('Top') &&
                !warning.date.includes('Top')
              );
              actualWarnings.forEach((warning, index) => {
                additionalInfo += `${index + 1}. **${warning.name}**\n`;
                additionalInfo += `   📅 Ngày: ${warning.date}\n`;
                additionalInfo += `   👁️ Lượt xem: ${warning.views}\n`;
                additionalInfo += `   🔗 Link: ${warning.link}\n\n`;
              });
            }
          }
        } else {
          additionalInfo = `❓ KẾT QUẢ CHO "${query}":\n• Chưa xác định - Không có thông tin rõ ràng\n\n`;
        }
      } catch (e) {
        additionalInfo = `❓ KẾT QUẢ CHO "${query}":\n• Chưa xác định - Không thể truy xuất thông tin\n\n`;
      }

      await page.close();
      return additionalInfo.trim();

    } catch (error) {
      if (error.message.includes('net::ERR_FAILED')) {
        return `❌ LỖI MẠNG: Không thể truy cập trang web. Có thể do:\n• URL quá dài hoặc có ký tự đặc biệt\n• Vấn đề kết nối mạng\n• Trang web bị chặn hoặc không tồn tại`;
      } else if (error.message.includes('net::ERR_CONNECTION_TIMED_OUT')) {
        return `⏰ LỖI TIMEOUT: Kết nối bị timeout. Vui lòng thử lại sau.`;
      } else if (error.message.includes('net::ERR_NAME_NOT_RESOLVED')) {
        return `🌐 LỖI DNS: Không thể phân giải tên miền. Kiểm tra lại URL.`;
      } else if (error.message.includes('net::ERR_CONNECTION_REFUSED')) {
        return `🚫 LỖI KẾT NỐI: Kết nối bị từ chối. Trang web có thể đang bảo trì.`;
      } else {
        return `❌ LỖI KHÔNG XÁC ĐỊNH: ${error.message}`;
      }
    }
  }

  extractItems(text) {
    const phoneRegex = /0\d{9}/g;
    const facebookRegex = /(?:https?:\/\/)?(?:www\.)?(?:facebook\.com|fb\.com|m\.facebook\.com)\/[^\s]+/gi;
    return [...new Set([...(text.match(phoneRegex) || []), ...(text.match(facebookRegex) || [])])];
  }
}

module.exports = new ScamChecker();
