import { Client, GatewayIntentBits, Events, Collection } from 'discord.js';
import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildVoiceStates
  ]
});

client.commands = new Collection();
client.logChannel = null;
client.voiceStats = {};
client.voiceStartTimes = {};
const DATA_FILE = path.join(__dirname, 'data', 'voiceStats.json');

function saveStats() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(client.voiceStats, null, 2));
}

function loadStats() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      client.voiceStats = JSON.parse(fs.readFileSync(DATA_FILE));
    }
  } catch (err) {
    console.error('❌ Failed to load stats:', err);
  }
}

client.once(Events.ClientReady, () => {
  console.log(`✅ Bot logged in as ${client.user.tag}`);
  loadStats();
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const { commandName } = interaction;

  if (commandName === 'ping') {
    const sent = await interaction.reply({ content: 'Pinging...', fetchReply: true });
    interaction.editReply(`Pong! Roundtrip latency: ${sent.createdTimestamp - interaction.createdTimestamp}ms`);
  } else if (commandName === 'uptime') {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    interaction.reply(`🕒 Bot uptime: ${hours}h ${minutes}m ${seconds}s`);
  } else if (commandName === 'help') {
    interaction.reply(`/ping – Kiểm tra độ trễ
/uptime – Thời gian hoạt động
/topvoice – Top voice
/setlogchannel – Cài kênh log
/help – Danh sách lệnh`);
  } else if (commandName === 'setlogchannel') {
    const channel = interaction.options.getChannel('channel');
    client.logChannel = channel;
    interaction.reply(`📢 Log channel set to ${channel.name}`);
  } else if (commandName === 'topvoice') {
    const sorted = Object.entries(client.voiceStats)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([userId, time], index) => `${index + 1}. <@${userId}> – ${Math.floor(time / 60)} phút`);

    interaction.reply({ content: '🏆 Top voice users:
' + sorted.join('
'), allowedMentions: { parse: [] } });
  }
});

client.on(Events.VoiceStateUpdate, (oldState, newState) => {
  const user = newState.member.user;
  const userId = user.id;
  const now = Date.now();

  // Join voice
  if (!oldState.channelId && newState.channelId) {
    client.voiceStartTimes[userId] = now;

    // Bot join nếu có ít nhất 1 người
    if (newState.channel.members.size === 1) {
      newState.channel.joinable && newState.channel.guild.members.me.voice.channel?.leave?.();
    }
  }

  // Leave voice
  if (oldState.channelId && !newState.channelId) {
    const joinedAt = client.voiceStartTimes[userId];
    if (joinedAt) {
      const duration = Math.floor((now - joinedAt) / 1000);
      client.voiceStats[userId] = (client.voiceStats[userId] || 0) + duration;
      delete client.voiceStartTimes[userId];
      saveStats();

      if (client.logChannel) {
        client.logChannel.send(`👋 <@${userId}> đã rời voice sau ${Math.floor(duration / 60)} phút.`);
      }
    }
  }
});

client.login(process.env.TOKEN);
