import { REST, Routes, SlashCommandBuilder } from 'discord.js';
import 'dotenv/config';

const commands = [
  new SlashCommandBuilder().setName('ping').setDescription('Check bot latency'),
  new SlashCommandBuilder().setName('uptime').setDescription('Bot uptime'),
  new SlashCommandBuilder().setName('topvoice').setDescription('Show top voice users'),
  new SlashCommandBuilder().setName('setlogchannel')
    .setDescription('Set channel for voice logs')
    .addChannelOption(option =>
      option.setName('channel').setDescription('Log channel').setRequired(true)),
  new SlashCommandBuilder().setName('help').setDescription('List commands')
].map(command => command.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

try {
  console.log('🔄 Deploying slash commands globally...');
  await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commands });
  console.log('✅ Slash commands deployed globally');
} catch (error) {
  console.error(error);
}